import { app } from "/scripts/app.js";
import { api } from "/scripts/api.js";

// DWPose Editor Extension for ComfyUI
// Adds "Edit Pose" button to DWPoseJSONRenderer node

let editorWindow = null;
let pendingNodeId = null;

// Listen for messages from editor popup
window.addEventListener('message', async (event) => {
    if (event.data && event.data.type === 'editorReady') {
        // Editor is ready, send current pose data if available
        const nodeId = event.data.nodeId;
        const node = app.graph.getNodeById(parseInt(nodeId));

        if (node && editorWindow) {
            // 1번칸 (json_input) 먼저 확인, 없으면 2번칸 (json_override) 확인
            let jsonWidget = node.widgets?.find(w => w.name === 'json_input');
            let jsonValue = jsonWidget?.value;

            // json_input이 비어있으면 json_override 확인
            if (!jsonValue || !jsonValue.trim()) {
                const overrideWidget = node.widgets?.find(w => w.name === 'json_override');
                jsonValue = overrideWidget?.value;
            }

            if (jsonValue && jsonValue.trim()) {
                editorWindow.postMessage({
                    type: 'loadPose',
                    json: jsonValue
                }, '*');
            }

            // 배경 이미지: 렌더러 노드 출력의 source_image (images[1]) 사용
            // ui_images 순서: [0]=blend_image, [1]=source_image
            try {
                let imageUrl = null;
                const selfId = node.id;
                const SOURCE_IMG_IDX = 1; // source_image 인덱스

                // Method 1: node.imgs[1] (source_image 프리뷰)
                if (node.imgs?.[SOURCE_IMG_IDX]?.src) {
                    imageUrl = node.imgs[SOURCE_IMG_IDX].src;
                }

                // Method 2: app.nodeOutputs[node.id].images[1] → /view URL
                if (!imageUrl) {
                    const nodeOutput = app.nodeOutputs?.[selfId];
                    if (nodeOutput?.images?.[SOURCE_IMG_IDX]) {
                        const imgInfo = nodeOutput.images[SOURCE_IMG_IDX];
                        const params = new URLSearchParams({
                            filename: imgInfo.filename,
                            subfolder: imgInfo.subfolder || '',
                            type: imgInfo.type || 'output'
                        });
                        imageUrl = api.apiURL('/view?' + params.toString());
                    }
                }

                // Method 3: /history API fallback
                if (!imageUrl) {
                    try {
                        const resp = await api.fetchApi('/history?max_items=5');
                        if (resp.ok) {
                            const historyData = await resp.json();
                            for (const promptId of Object.keys(historyData).reverse()) {
                                const nodeOut = historyData[promptId]?.outputs?.[selfId];
                                if (nodeOut?.images?.[SOURCE_IMG_IDX]) {
                                    const imgInfo = nodeOut.images[SOURCE_IMG_IDX];
                                    const params = new URLSearchParams({
                                        filename: imgInfo.filename,
                                        subfolder: imgInfo.subfolder || '',
                                        type: imgInfo.type || 'output'
                                    });
                                    imageUrl = api.apiURL('/view?' + params.toString());
                                    break;
                                }
                            }
                        }
                    } catch (histErr) {
                        // /history API 실패 시 무시
                    }
                }

                if (imageUrl) {
                    editorWindow.postMessage({
                        type: 'loadBackground',
                        imageData: imageUrl
                    }, '*');
                }
            } catch (e) {
                console.warn('Failed to send background image:', e);
            }
        }
    }
    else if (event.data && event.data.type === 'poseData') {
        // Received pose data from editor
        const nodeId = event.data.nodeId;
        const json = event.data.json;

        const node = app.graph.getNodeById(parseInt(nodeId));
        if (node) {
            // 2번칸 (json_override)에 저장!
            const overrideWidget = node.widgets?.find(w => w.name === 'json_override');
            if (overrideWidget) {
                overrideWidget.value = json;
                node.setDirtyCanvas(true);
            }
        }

        editorWindow = null;
    }
});

app.registerExtension({
    name: "DWPose.Editor",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        // Only apply to DWPoseJSONRenderer node
        if (nodeData.name !== "DWPoseJSONRenderer") {
            return;
        }

        const onNodeCreated = nodeType.prototype.onNodeCreated;

        nodeType.prototype.onNodeCreated = function() {
            const result = onNodeCreated?.apply(this, arguments);

            // json_input 위젯 숨기기
            // 이미지에서 자동 추출되는 내부 필드이므로 사용자에게 노출할 필요 없음
            // 위젯 자체는 유지 (값 읽기/쓰기 가능), UI에서만 숨김
            const jsonInputWidget = this.widgets?.find(w => w.name === 'json_input');
            if (jsonInputWidget) {
                jsonInputWidget.type = "converted-widget";
                jsonInputWidget.computeSize = () => [0, -4];
            }

            // Add Edit Pose button
            const editButton = this.addWidget("button", "✏️ Edit Pose", null, () => {
                openEditor(this);
            });

            return result;
        };
    }
});

function openEditor(node) {
    // Get editor HTML path
    const editorPath = new URL('dwpose_editor.html', import.meta.url).href.replace('/js/', '/');

    // Calculate window size and position (화면 크기에 비례)
    const width = Math.min(1400, Math.floor(screen.width * 0.85));
    const height = Math.min(900, Math.floor(screen.height * 0.85));
    const left = (screen.width - width) / 2;
    const top = (screen.height - height) / 2;

    // Close existing editor window if open
    if (editorWindow && !editorWindow.closed) {
        editorWindow.close();
    }

    // Open editor popup
    editorWindow = window.open(
        `${editorPath}?nodeId=${node.id}`,
        'DWPose Editor',
        `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=no`
    );

    pendingNodeId = node.id;

    // Focus the window
    if (editorWindow) {
        editorWindow.focus();
    }
}
