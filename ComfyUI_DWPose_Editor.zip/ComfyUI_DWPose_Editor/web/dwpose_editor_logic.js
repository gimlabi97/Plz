// ========== ComfyUI 통신 ==========
let nodeId = null;

// URL에서 nodeId 가져오기
const urlParams = new URLSearchParams(window.location.search);
nodeId = urlParams.get('nodeId');

// 초기 JSON 데이터 받기
window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'loadPose') {
        try {
            loadJSON(event.data.json);
        } catch (e) {
            console.error('Failed to load pose:', e);
        }
    }
    else if (event.data && event.data.type === 'loadBackground') {
        try {
            loadBackgroundFromUrl(event.data.imageData);
        } catch (e) {
            console.error('Failed to load background:', e);
        }
    }
});

// URL에서 배경 이미지 로드
function loadBackgroundFromUrl(url) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
        backgroundImage = img;
        render();
        showStatus('배경 이미지 자동 로드됨');
    };
    img.onerror = () => {};
    img.src = url;
}

// Node로 JSON 전송
function sendToNode() {
    const output = getJSONOutput();

    if (window.opener) {
        window.opener.postMessage({
            type: 'poseData',
            nodeId: nodeId,
            json: JSON.stringify(output)
        }, '*');
        showStatus('✓ Sent to Node!');

        // 1초 후 창 닫기
        setTimeout(() => window.close(), 1000);
    } else {
        // 팝업이 아닌 경우 클립보드에 복사
        navigator.clipboard.writeText(JSON.stringify(output, null, 2)).then(() => {
            showStatus('✓ Copied to clipboard!');
        });
    }
}

function getJSONOutput() {
    return {
        people: [{
            pose_keypoints_2d: poseData.pose_keypoints_2d,
            hand_left_keypoints_2d: poseData.hand_left_keypoints_2d,
            hand_right_keypoints_2d: poseData.hand_right_keypoints_2d,
            face_keypoints_2d: poseData.face_keypoints_2d
        }],
        canvas_width: canvasWidth,
        canvas_height: canvasHeight
    };
}

// ==========================================================================
// 상수 - dwpose/util.py의 draw_bodypose_with_feet, draw_handpose, draw_facepose와 동일
//
// [렌더러 대응 관계]
// - BODY_COLORS  → util.py draw_bodypose_with_feet()의 colors 배열 (24색, RGB)
// - LIMB_SEQ     → util.py draw_bodypose_with_feet()의 limbSeq (25개 연결)
//                   ※ draw_bodypose_without_feet는 17개만 그림 (show_feet=False일 때)
//                   ※ 에디터는 항상 with_feet 기준으로 렌더링 (feet 키포인트 없으면 자동 스킵)
// - HAND_EDGES   → util.py draw_handpose()의 edges (20개 연결)
// - 손 선 색상   → util.py: HSV→RGB→BGR, 에디터: HSL→RGB→R/B swap (렌더러 BGR 출력 매칭)
// - 손 점 색상   → util.py: BGR(0,0,255), 에디터: rgb(0,0,255) (렌더러 BGR 출력 매칭)
// - 얼굴 점 색상 → util.py: BGR(255,255,255)=흰색 = 에디터: rgb(255,255,255) (동일)
// ==========================================================================

// Body 키포인트 색상 (24색) - util.py draw_bodypose_with_feet()의 colors와 동일
// 인덱스 0~17: 기본 body, 18~23: feet (발 관절은 ankle 색상으로 통일됨)
const BODY_COLORS = [
    [255, 0, 0], [255, 85, 0], [255, 170, 0], [255, 255, 0], [170, 255, 0],
    [85, 255, 0], [0, 255, 0], [0, 255, 85], [0, 255, 170], [0, 255, 255],
    [0, 170, 255], [0, 85, 255], [0, 0, 255], [85, 0, 255], [170, 0, 255],
    [255, 0, 255], [255, 0, 170], [255, 0, 85], [85, 0, 255], [85, 0, 255],
    [85, 0, 255], [0, 170, 255], [0, 170, 255], [0, 170, 255]
];

// Body 뼈대 연결 (1-indexed, 25개) - util.py draw_bodypose_with_feet()의 limbSeq과 동일
// [0~16] 17개: 기본 body 연결 (목-어깨, 팔, 다리, 머리 등)
// [17~24] 8개: feet 연결 (발목-발가락, 발목-발뒤꿈치 등)
const LIMB_SEQ = [
    [2, 3], [2, 6], [3, 4], [4, 5], [6, 7], [7, 8], [2, 9], [9, 10],
    [10, 11], [2, 12], [12, 13], [13, 14], [2, 1], [1, 15], [15, 17],
    [1, 16], [16, 18], [11, 24], [14, 21], [19, 21], [19, 20], [20, 21],
    [22, 24], [22, 23], [23, 24]
];

// Hand 뼈대 연결 (0-indexed, 20개) - util.py draw_handpose()의 edges와 동일
// 5개 손가락 × 4개 관절 연결
const HAND_EDGES = [
    [0, 1], [1, 2], [2, 3], [3, 4],
    [0, 5], [5, 6], [6, 7], [7, 8],
    [0, 9], [9, 10], [10, 11], [11, 12],
    [0, 13], [13, 14], [14, 15], [15, 16],
    [0, 17], [17, 18], [18, 19], [19, 20]
];

const BODY_NAMES = [
    '코', '목', '오른어깨', '오른팔꿈치', '오른손목', '왼어깨', '왼팔꿈치', '왼손목',
    '오른엉덩', '오른무릎', '오른발목', '왼엉덩', '왼무릎', '왼발목',
    '오른눈', '왼눈', '오른귀', '왼귀',
    '왼엄지발', '왼새끼발', '왼발뒤꿈치', '오른엄지발', '오른새끼발', '오른발뒤꿈치'
];

const HAND_NAMES = [
    '손목',
    '엄지CMC', '엄지MCP', '엄지IP', '엄지끝',
    '검지MCP', '검지PIP', '검지DIP', '검지끝',
    '중지MCP', '중지PIP', '중지DIP', '중지끝',
    '약지MCP', '약지PIP', '약지DIP', '약지끝',
    '소지MCP', '소지PIP', '소지DIP', '소지끝'
];

const FACE_NAMES = [
    // 턱라인 0-16
    '우관자놀이', '우턱위1', '우턱위2', '우턱위3',
    '우턱1', '우턱2', '우턱3',
    '턱중앙우', '턱끝', '턱중앙좌',
    '좌턱1', '좌턱2', '좌턱3',
    '좌턱위1', '좌턱위2', '좌턱위3', '좌관자놀이',
    // 오른눈썹 17-21
    '우눈썹안쪽', '우눈썹안중', '우눈썹중간', '우눈썹바중', '우눈썹바깥',
    // 왼눈썹 22-26
    '좌눈썹안쪽', '좌눈썹안중', '좌눈썹중간', '좌눈썹바중', '좌눈썹바깥',
    // 코 27-35
    '콧대위', '콧대중상', '콧대중하', '콧대아래',
    '우콧볼위', '우콧볼', '코끝', '좌콧볼', '좌콧볼위',
    // 오른눈 36-41
    '우눈안끝', '우눈위안', '우눈위밖', '우눈밖끝', '우눈아래밖', '우눈아래안',
    // 왼눈 42-47
    '좌눈안끝', '좌눈위안', '좌눈위밖', '좌눈밖끝', '좌눈아래밖', '좌눈아래안',
    // 입 바깥 48-59
    '입우끝', '윗입술우', '윗입술우중', '윗입술중앙', '윗입술좌중', '윗입술좌',
    '입좌끝', '아랫입술좌', '아랫입술좌중', '아랫입술중앙', '아랫입술우중', '아랫입술우',
    // 입 안쪽 60-67
    '윗입안우', '윗입안중', '윗입안좌',
    '입안좌끝',
    '아랫입안좌', '아랫입안중', '아랫입안우',
    '입안우끝'
];

const PART_COUNTS = { body: 24, face: 68, leftHand: 21, rightHand: 21 };

// ========== FK 관절 체인 시스템 ==========
const JOINT = {
    NOSE: 0, NECK: 1,
    R_SHOULDER: 2, R_ELBOW: 3, R_WRIST: 4,
    L_SHOULDER: 5, L_ELBOW: 6, L_WRIST: 7,
    R_HIP: 8, R_KNEE: 9, R_ANKLE: 10,
    L_HIP: 11, L_KNEE: 12, L_ANKLE: 13,
    R_EYE: 14, L_EYE: 15, R_EAR: 16, L_EAR: 17,
    L_BIGTOE: 18, L_SMALLTOE: 19, L_HEEL: 20,
    R_BIGTOE: 21, R_SMALLTOE: 22, R_HEEL: 23
};

const BONE_HIERARCHY = {
    [JOINT.NECK]: {
        children: [JOINT.NOSE, JOINT.R_SHOULDER, JOINT.L_SHOULDER, JOINT.R_HIP, JOINT.L_HIP],
        includesFace: false
    },
    [JOINT.NOSE]: {
        children: [JOINT.R_EYE, JOINT.L_EYE],
        includesFace: true
    },
    [JOINT.R_EYE]: { children: [JOINT.R_EAR] },
    [JOINT.L_EYE]: { children: [JOINT.L_EAR] },
    [JOINT.R_SHOULDER]: { children: [JOINT.R_ELBOW] },
    [JOINT.R_ELBOW]: { children: [JOINT.R_WRIST] },
    [JOINT.R_WRIST]: { children: [], includesHand: 'right' },
    [JOINT.L_SHOULDER]: { children: [JOINT.L_ELBOW] },
    [JOINT.L_ELBOW]: { children: [JOINT.L_WRIST] },
    [JOINT.L_WRIST]: { children: [], includesHand: 'left' },
    [JOINT.R_HIP]: { children: [JOINT.R_KNEE] },
    [JOINT.R_KNEE]: { children: [JOINT.R_ANKLE] },
    [JOINT.R_ANKLE]: { children: [JOINT.R_BIGTOE, JOINT.R_SMALLTOE, JOINT.R_HEEL] },
    [JOINT.L_HIP]: { children: [JOINT.L_KNEE] },
    [JOINT.L_KNEE]: { children: [JOINT.L_ANKLE] },
    [JOINT.L_ANKLE]: { children: [JOINT.L_BIGTOE, JOINT.L_SMALLTOE, JOINT.L_HEEL] }
};

function rotateJoint(pivotJointId, angleDeg) {
    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 24 * 3) return;

    const pivotX = kpts[pivotJointId * 3];
    const pivotY = kpts[pivotJointId * 3 + 1];

    if (kpts[pivotJointId * 3 + 2] <= 0) return;

    const angleRad = angleDeg * Math.PI / 180;
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);

    const toRotate = collectChildren(pivotJointId);

    toRotate.bodyJoints.forEach(jointId => {
        if (jointId * 3 + 2 >= kpts.length) return;
        if (kpts[jointId * 3 + 2] <= 0) return;
        const x = kpts[jointId * 3] - pivotX;
        const y = kpts[jointId * 3 + 1] - pivotY;
        kpts[jointId * 3] = pivotX + x * cos - y * sin;
        kpts[jointId * 3 + 1] = pivotY + x * sin + y * cos;
    });

    if (toRotate.includesRightHand) {
        rotateHandAroundPivot('right', pivotX, pivotY, cos, sin);
    }
    if (toRotate.includesLeftHand) {
        rotateHandAroundPivot('left', pivotX, pivotY, cos, sin);
    }
    if (toRotate.includesFace) {
        rotateFaceAroundPivot(pivotX, pivotY, cos, sin);
    }
}

function collectChildren(jointId) {
    const result = {
        bodyJoints: [],
        includesRightHand: false,
        includesLeftHand: false,
        includesFace: false
    };

    const visited = new Set();
    const queue = [jointId];

    while (queue.length > 0) {
        const current = queue.shift();
        if (visited.has(current)) continue;
        visited.add(current);

        const node = BONE_HIERARCHY[current];
        if (!node) continue;

        node.children.forEach(child => {
            result.bodyJoints.push(child);
            queue.push(child);
        });

        if (node.includesHand === 'right') result.includesRightHand = true;
        if (node.includesHand === 'left') result.includesLeftHand = true;
        if (node.includesFace) result.includesFace = true;
    }

    return result;
}

function rotateHandAroundPivot(side, pivotX, pivotY, cos, sin) {
    const kpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const numPts = Math.floor(kpts.length / 3);
    for (let i = 0; i < numPts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        const x = kpts[i * 3] - pivotX;
        const y = kpts[i * 3 + 1] - pivotY;
        kpts[i * 3] = pivotX + x * cos - y * sin;
        kpts[i * 3 + 1] = pivotY + x * sin + y * cos;
    }
}

function rotateFaceAroundPivot(pivotX, pivotY, cos, sin) {
    const kpts = poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const numPts = Math.floor(kpts.length / 3);
    for (let i = 0; i < numPts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        const x = kpts[i * 3] - pivotX;
        const y = kpts[i * 3 + 1] - pivotY;
        kpts[i * 3] = pivotX + x * cos - y * sin;
        kpts[i * 3 + 1] = pivotY + x * sin + y * cos;
    }

    baseFaceData = null;
}

function getJointAngle(parentId, childId) {
    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 24 * 3) return 0;
    const px = kpts[parentId * 3];
    const py = kpts[parentId * 3 + 1];
    const cx = kpts[childId * 3];
    const cy = kpts[childId * 3 + 1];
    return Math.atan2(cy - py, cx - px) * 180 / Math.PI;
}

// ========== 상태 ==========
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

let canvasWidth = 512, canvasHeight = 768;
let zoom = 1;
let backgroundImage = null;

let showBackground = true;
let showSkeleton = true;

let poseData = {
    pose_keypoints_2d: [],
    hand_left_keypoints_2d: [],
    hand_right_keypoints_2d: [],
    face_keypoints_2d: []
};

let selectedPoints = [];
let isDragging = false;
let dragStartX = 0, dragStartY = 0;
let dragPointsStart = [];

let isBoxSelecting = false;
let boxStartX = 0, boxStartY = 0, boxEndX = 0, boxEndY = 0;

let isPanning = false;
let panStartX = 0, panStartY = 0;
let panScrollStartX = 0, panScrollStartY = 0;
let spacePressed = false;

let history = [];
let historyIndex = -1;
const MAX_HISTORY = 50;

// ========== 헬퍼 함수 ==========
let handPresetBase = { left: null, right: null };

function resetAllBases() {
    baseFaceData = null;
    fkBasePose = null;
    transplantBasePose = null;
    currentHeadPreset = null;
    handPresetBase = { left: null, right: null };
}

function resetAllSliders() {
    ['fkHead', 'fkRShoulder', 'fkRElbow', 'fkRWrist',
     'fkLShoulder', 'fkLElbow', 'fkLWrist',
     'fkRHip', 'fkRKnee', 'fkLHip', 'fkLKnee'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.value = 0;
            const valEl = document.getElementById(id + 'Value');
            if (valEl) valEl.textContent = '0°';
        }
    });

    ['gazeX', 'gazeY', 'mouthOpen', 'eyeClose'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = 0;
    });
    const exprVals = {
        'gazeXValue': '0', 'gazeYValue': '0',
        'mouthOpenValue': '0', 'eyeCloseValue': '0'
    };
    Object.entries(exprVals).forEach(([id, val]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    });

    currentHeadPreset = null;
    updateHeadPresetUI();
}

// ========== 초기화 ==========
function init() {
    createToggleButtons();
    setupEventListeners();

    // 초기 줌 100%, 스크롤로 탐색
    zoom = 1;
    applyZoom();
    document.getElementById('statusZoom').textContent = '100%';
    setTimeout(() => centerCanvas(), 100);

    // 부모 창에 준비 완료 알림
    if (window.opener) {
        window.opener.postMessage({ type: 'editorReady', nodeId: nodeId }, '*');
    }
}

const BODY_GROUPS = [
    { name: '머리', indices: [0, 1, 14, 15, 16, 17] },
    { name: '오른팔', indices: [2, 3, 4] },
    { name: '왼팔', indices: [5, 6, 7] },
    { name: '오른다리', indices: [8, 9, 10] },
    { name: '왼다리', indices: [11, 12, 13] },
    { name: '오른발', indices: [21, 22, 23] },
    { name: '왼발', indices: [18, 19, 20] }
];

const HAND_GROUPS = [
    { name: '손목', indices: [0] },
    { name: '엄지', indices: [1, 2, 3, 4] },
    { name: '검지', indices: [5, 6, 7, 8] },
    { name: '중지', indices: [9, 10, 11, 12] },
    { name: '약지', indices: [13, 14, 15, 16] },
    { name: '소지', indices: [17, 18, 19, 20] }
];

const FACE_GROUPS = [
    { name: '턱라인', indices: Array.from({length: 17}, (_, i) => i) },
    { name: '왼눈썹', indices: [17, 18, 19, 20, 21] },
    { name: '오른눈썹', indices: [22, 23, 24, 25, 26] },
    { name: '코', indices: [27, 28, 29, 30, 31, 32, 33, 34, 35] },
    { name: '왼눈', indices: [36, 37, 38, 39, 40, 41] },
    { name: '오른눈', indices: [42, 43, 44, 45, 46, 47] },
    { name: '입 바깥', indices: [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59] },
    { name: '입 안쪽', indices: [60, 61, 62, 63, 64, 65, 66, 67] }
];

function createGroupedToggles(container, type, groups, nameArray) {
    groups.forEach(group => {
        const groupDiv = document.createElement('div');
        groupDiv.className = 'toggle-group';
        groupDiv.dataset.type = type;

        const header = document.createElement('div');
        header.className = 'toggle-group-header';
        header.innerHTML = `
            <span class="toggle-group-arrow">▶</span>
            <span class="toggle-group-name">${group.name}</span>
            <span class="toggle-group-count" data-group-type="${type}" data-group-name="${group.name}">${group.indices.length}/${group.indices.length}</span>
            <button class="accordion-btn" title="모두 켜기" onclick="event.stopPropagation(); toggleGroup('${type}', [${group.indices}], true)">ON</button>
            <button class="accordion-btn" title="모두 끄기" onclick="event.stopPropagation(); toggleGroup('${type}', [${group.indices}], false)">OFF</button>
        `;
        header.onclick = (e) => {
            if (e.target.tagName === 'BUTTON') return;
            groupDiv.classList.toggle('open');
        };
        groupDiv.appendChild(header);

        const content = document.createElement('div');
        content.className = 'toggle-group-content';
        const grid = document.createElement('div');
        grid.className = 'toggle-grid';

        group.indices.forEach(i => {
            const btn = document.createElement('button');
            btn.className = 'toggle-btn on';
            btn.textContent = nameArray[i] || i;
            btn.title = nameArray[i] || `${type} ${i}`;
            btn.dataset.type = type;
            btn.dataset.index = i;
            btn.onclick = () => togglePoint(type, i);
            grid.appendChild(btn);
        });

        content.appendChild(grid);
        groupDiv.appendChild(content);
        container.appendChild(groupDiv);
    });
}

function toggleGroup(type, indices, turnOn) {
    saveHistory();
    const arr = getArrayByType(type);
    while (arr.length < Math.max(...indices) * 3 + 3) arr.push(0, 0, 0);

    indices.forEach(i => {
        if (turnOn) {
            if (arr[i * 3] === 0 && arr[i * 3 + 1] === 0) {
                arr[i * 3] = canvasWidth / 2 + (Math.random() - 0.5) * 100;
                arr[i * 3 + 1] = canvasHeight / 2 + (Math.random() - 0.5) * 100;
            }
            arr[i * 3 + 2] = 1.0;
        } else {
            arr[i * 3 + 2] = 0;
        }
    });

    updateUI();
    render();
    showStatus(turnOn ? `${type} 그룹 켜기` : `${type} 그룹 끄기`);
}

function createToggleButtons() {
    const bodyGrid = document.getElementById('toggles-body');
    createGroupedToggles(bodyGrid, 'body', BODY_GROUPS, BODY_NAMES);

    const faceGrid = document.getElementById('toggles-face');
    createGroupedToggles(faceGrid, 'face', FACE_GROUPS, FACE_NAMES);

    ['leftHand', 'rightHand'].forEach(hand => {
        const grid = document.getElementById(`toggles-${hand}`);
        createGroupedToggles(grid, hand, HAND_GROUPS, HAND_NAMES);
    });
}

function setupEventListeners() {
    const wrapper = document.getElementById('canvasWrapper');
    wrapper.addEventListener('mousedown', onMouseDown);
    wrapper.addEventListener('mousemove', onMouseMove);
    wrapper.addEventListener('mouseup', onMouseUp);
    wrapper.addEventListener('mouseleave', onMouseUp);
    wrapper.addEventListener('contextmenu', onRightClick);
    wrapper.addEventListener('wheel', onWheel, { passive: false });

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
}

// ========== 유틸 ==========
function getArrayByType(type) {
    switch(type) {
        case 'body': return poseData.pose_keypoints_2d;
        case 'leftHand': return poseData.hand_left_keypoints_2d;
        case 'rightHand': return poseData.hand_right_keypoints_2d;
        case 'face': return poseData.face_keypoints_2d;
    }
}

function getNameByTypeAndIndex(type, index) {
    if (type === 'body') return BODY_NAMES[index] || `Body ${index}`;
    if (type === 'leftHand') return `왼${HAND_NAMES[index]}` || `왼손 ${index}`;
    if (type === 'rightHand') return `오른${HAND_NAMES[index]}` || `오른손 ${index}`;
    if (type === 'face') return FACE_NAMES[index] || `얼굴 ${index}`;
}

function showStatus(msg) {
    const el = document.getElementById('statusMsg');
    el.textContent = msg;
    setTimeout(() => el.textContent = '', 2000);
}

// ========== History ==========
function saveHistory() {
    const state = JSON.stringify(poseData);
    history = history.slice(0, historyIndex + 1);
    if (history.length > 0 && history[history.length - 1] === state) return;
    history.push(state);
    historyIndex = history.length - 1;
    if (history.length > MAX_HISTORY) { history.shift(); historyIndex--; }
}

function undo() {
    if (historyIndex > 0) {
        historyIndex--;
        poseData = JSON.parse(history[historyIndex]);
        resetAllBases();
        resetAllSliders();
        selectedPoints = [];
        updateUI();
        render();
        showStatus('실행취소');
    }
}

function redo() {
    if (historyIndex < history.length - 1) {
        historyIndex++;
        poseData = JSON.parse(history[historyIndex]);
        resetAllBases();
        resetAllSliders();
        selectedPoints = [];
        updateUI();
        render();
        showStatus('다시실행');
    }
}

// ========== UI 업데이트 ==========
function updateUI() {
    document.querySelectorAll('.toggle-btn').forEach(btn => {
        const type = btn.dataset.type;
        const idx = parseInt(btn.dataset.index);
        const arr = getArrayByType(type);
        const isOn = arr.length > idx * 3 + 2 && arr[idx * 3 + 2] > 0;
        btn.classList.toggle('on', isOn);
    });

    Object.keys(PART_COUNTS).forEach(part => {
        const arr = getArrayByType(part);
        let count = 0;
        for (let i = 0; i < PART_COUNTS[part] && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] > 0) count++;
        }
        document.getElementById(`count-${part}`).textContent = `${count}/${PART_COUNTS[part]}`;
    });

    let total = 0;
    Object.keys(PART_COUNTS).forEach(part => {
        const arr = getArrayByType(part);
        for (let i = 0; i < PART_COUNTS[part] && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] > 0) total++;
        }
    });
    document.getElementById('statusPoints').textContent = `${total}/134 points`;
    document.getElementById('statusSelected').textContent = `${selectedPoints.length} selected`;
    document.getElementById('statusSize').textContent = `${canvasWidth} × ${canvasHeight}`;

    const info = document.getElementById('selectionInfo');
    if (selectedPoints.length === 0) info.textContent = '선택: 없음';
    else if (selectedPoints.length === 1) info.textContent = `선택: ${selectedPoints[0].name}`;
    else info.textContent = `선택: ${selectedPoints.length}개`;

    updateCoordInputs();
}

function updateCoordInputs() {
    const coordX = document.getElementById('coordX');
    const coordY = document.getElementById('coordY');
    if (selectedPoints.length === 1) {
        const p = selectedPoints[0];
        const arr = getArrayByType(p.type);
        coordX.value = Math.round(arr[p.index * 3]);
        coordY.value = Math.round(arr[p.index * 3 + 1]);
    } else {
        coordX.value = '';
        coordY.value = '';
    }
}

function updateDisplay() {
    document.getElementById('lineThicknessValue').textContent = document.getElementById('lineThickness').value;
    document.getElementById('pointRadiusValue').textContent = document.getElementById('pointRadius').value;
    render();
}

// ========== 배경/스켈레톤 토글 ==========
function toggleBackground() {
    showBackground = !showBackground;
    document.getElementById('toggleBg').textContent = showBackground ? '배경 ON' : '배경 OFF';
    document.getElementById('toggleBg').classList.toggle('on', showBackground);
    render();
}

function toggleSkeleton() {
    showSkeleton = !showSkeleton;
    document.getElementById('toggleSkeleton').textContent = showSkeleton ? '스켈레톤 ON' : '스켈레톤 OFF';
    document.getElementById('toggleSkeleton').classList.toggle('on', showSkeleton);
    render();
}

function updateBgOpacity() {
    document.getElementById('bgOpacityValue').textContent = document.getElementById('bgOpacity').value + '%';
    render();
}

function updatePoseOpacity() {
    const val = parseInt(document.getElementById('poseOpacity').value);
    document.getElementById('poseOpacityValue').textContent = val + '%';
    render();
}

// ========== 토글 ==========
function toggleAccordion(header) {
    header.parentElement.classList.toggle('open');
}

function togglePoint(type, index) {
    saveHistory();
    const arr = getArrayByType(type);
    while (arr.length < (index + 1) * 3) arr.push(0, 0, 0);

    if (arr[index * 3 + 2] > 0) {
        arr[index * 3 + 2] = 0;
    } else {
        if (arr[index * 3] === 0 && arr[index * 3 + 1] === 0) {
            arr[index * 3] = canvasWidth / 2 + (Math.random() - 0.5) * 100;
            arr[index * 3 + 1] = canvasHeight / 2 + (Math.random() - 0.5) * 100;
        }
        arr[index * 3 + 2] = 1.0;
    }

    updateUI();
    render();
}

function toggleAllPart(type, turnOn) {
    saveHistory();
    const arr = getArrayByType(type);
    const count = PART_COUNTS[type];

    while (arr.length < count * 3) arr.push(0, 0, 0);

    for (let i = 0; i < count; i++) {
        if (turnOn) {
            if (arr[i * 3] === 0 && arr[i * 3 + 1] === 0) {
                arr[i * 3] = canvasWidth / 2 + (Math.random() - 0.5) * 100;
                arr[i * 3 + 1] = canvasHeight / 2 + (Math.random() - 0.5) * 100;
            }
            arr[i * 3 + 2] = 1.0;
        } else {
            arr[i * 3 + 2] = 0;
        }
    }

    updateUI();
    render();
    showStatus(turnOn ? `${type} 모두 켜기` : `${type} 모두 끄기`);
}

// ========== 좌표 ==========
function applyCoords() {
    if (selectedPoints.length !== 1) return;
    const x = parseFloat(document.getElementById('coordX').value);
    const y = parseFloat(document.getElementById('coordY').value);
    if (isNaN(x) || isNaN(y)) return;

    saveHistory();
    const p = selectedPoints[0];
    const arr = getArrayByType(p.type);
    arr[p.index * 3] = x;
    arr[p.index * 3 + 1] = y;
    render();
    showStatus('좌표 적용');
}

// ========== JSON ==========
function loadJSON(jsonStr) {
    let data = JSON.parse(jsonStr);
    if (Array.isArray(data)) data = data[0];

    if (data.canvas_width) {
        canvasWidth = data.canvas_width;
        canvasHeight = data.canvas_height || canvasHeight;
        canvas.width = canvasWidth;
        canvas.height = canvasHeight;
        document.getElementById('statusSize').textContent = `${canvasWidth} × ${canvasHeight}`;
    }

    if (data.people && data.people[0]) {
        const p = data.people[0];
        poseData.pose_keypoints_2d = p.pose_keypoints_2d || [];
        poseData.hand_left_keypoints_2d = p.hand_left_keypoints_2d || [];
        poseData.hand_right_keypoints_2d = p.hand_right_keypoints_2d || [];
        poseData.face_keypoints_2d = p.face_keypoints_2d || [];
    }

    resetAllBases();
    resetAllSliders();

    selectedPoints = [];
    saveHistory();
    updateUI();
    render();

    // 캔버스 중앙 정렬 (zoom 100% 유지)
    setTimeout(() => centerCanvas(), 100);

    showStatus('JSON 로드 완료');
}

// ========== 마우스 ==========
function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: (e.clientX - rect.left) * (canvas.width / rect.width),
        y: (e.clientY - rect.top) * (canvas.height / rect.height)
    };
}

function findNearestPoint(x, y) {
    const threshold = 15;
    let nearest = null, minDist = threshold;

    const check = (arr, type, maxPts) => {
        for (let i = 0; i < maxPts && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] <= 0) continue;
            const dist = Math.sqrt((x - arr[i * 3]) ** 2 + (y - arr[i * 3 + 1]) ** 2);
            if (dist < minDist) {
                minDist = dist;
                nearest = { type, index: i, name: getNameByTypeAndIndex(type, i) };
            }
        }
    };

    check(poseData.pose_keypoints_2d, 'body', 24);
    check(poseData.hand_left_keypoints_2d, 'leftHand', 21);
    check(poseData.hand_right_keypoints_2d, 'rightHand', 21);
    check(poseData.face_keypoints_2d, 'face', 68);

    return nearest;
}

function isPointSelected(type, index) {
    return selectedPoints.some(p => p.type === type && p.index === index);
}

function onMouseDown(e) {
    if (e.button === 1 || (e.button === 0 && spacePressed)) {
        e.preventDefault();
        isPanning = true;
        panStartX = e.clientX;
        panStartY = e.clientY;
        const wrapper = document.getElementById('canvasWrapper');
        panScrollStartX = wrapper.scrollLeft;
        panScrollStartY = wrapper.scrollTop;
        canvas.style.cursor = 'grabbing';
        return;
    }

    if (e.button !== 0) return;
    const pos = getMousePos(e);
    const point = findNearestPoint(pos.x, pos.y);

    if (point) {
        if (e.shiftKey) {
            const idx = selectedPoints.findIndex(p => p.type === point.type && p.index === point.index);
            if (idx >= 0) selectedPoints.splice(idx, 1);
            else selectedPoints.push(point);
        } else {
            if (!isPointSelected(point.type, point.index)) selectedPoints = [point];
        }

        isDragging = true;
        dragStartX = pos.x;
        dragStartY = pos.y;
        dragPointsStart = selectedPoints.map(p => {
            const arr = getArrayByType(p.type);
            return { x: arr[p.index * 3], y: arr[p.index * 3 + 1] };
        });
        saveHistory();
        canvas.style.cursor = 'grabbing';
    } else if (e.shiftKey) {
        isBoxSelecting = true;
        boxStartX = boxEndX = pos.x;
        boxStartY = boxEndY = pos.y;
    } else {
        selectedPoints = [];
    }

    updateUI();
    render();
}

function onMouseMove(e) {
    if (isPanning) {
        const wrapper = document.getElementById('canvasWrapper');
        wrapper.scrollLeft = panScrollStartX - (e.clientX - panStartX);
        wrapper.scrollTop = panScrollStartY - (e.clientY - panStartY);
        return;
    }

    const pos = getMousePos(e);
    document.getElementById('statusCoords').textContent = `X: ${Math.round(pos.x)}, Y: ${Math.round(pos.y)}`;

    if (isBoxSelecting) {
        boxEndX = pos.x;
        boxEndY = pos.y;
        render();
        drawSelectionBox();
    } else if (isDragging && selectedPoints.length > 0) {
        const dx = pos.x - dragStartX, dy = pos.y - dragStartY;
        selectedPoints.forEach((p, i) => {
            const arr = getArrayByType(p.type);
            arr[p.index * 3] = dragPointsStart[i].x + dx;
            arr[p.index * 3 + 1] = dragPointsStart[i].y + dy;
        });
        updateCoordInputs();
        render();
    } else {
        const point = findNearestPoint(pos.x, pos.y);
        const tooltip = document.getElementById('tooltip');
        if (point) {
            tooltip.textContent = point.name;
            tooltip.style.display = 'block';
            tooltip.style.left = (e.clientX + 10) + 'px';
            tooltip.style.top = (e.clientY + 10) + 'px';
            canvas.style.cursor = 'grab';
        } else {
            tooltip.style.display = 'none';
            canvas.style.cursor = spacePressed ? 'grab' : 'crosshair';
        }
    }
}

function onMouseUp(e) {
    if (isPanning) {
        isPanning = false;
        canvas.style.cursor = spacePressed ? 'grab' : 'crosshair';
        return;
    }

    if (isBoxSelecting) {
        selectPointsInBox();
        isBoxSelecting = false;
    }
    isDragging = false;
    canvas.style.cursor = 'crosshair';
    updateUI();
    render();
}

function selectPointsInBox() {
    const minX = Math.min(boxStartX, boxEndX), maxX = Math.max(boxStartX, boxEndX);
    const minY = Math.min(boxStartY, boxEndY), maxY = Math.max(boxStartY, boxEndY);
    if (maxX - minX < 5 && maxY - minY < 5) return;

    const check = (arr, type, maxPts) => {
        for (let i = 0; i < maxPts && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] <= 0) continue;
            const x = arr[i * 3], y = arr[i * 3 + 1];
            if (x >= minX && x <= maxX && y >= minY && y <= maxY) {
                if (!isPointSelected(type, i)) {
                    selectedPoints.push({ type, index: i, name: getNameByTypeAndIndex(type, i) });
                }
            }
        }
    };

    check(poseData.pose_keypoints_2d, 'body', 24);
    check(poseData.hand_left_keypoints_2d, 'leftHand', 21);
    check(poseData.hand_right_keypoints_2d, 'rightHand', 21);
    check(poseData.face_keypoints_2d, 'face', 68);
}

function drawSelectionBox() {
    ctx.strokeStyle = '#4a9eff';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);
    ctx.strokeRect(Math.min(boxStartX, boxEndX), Math.min(boxStartY, boxEndY),
        Math.abs(boxEndX - boxStartX), Math.abs(boxEndY - boxStartY));
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(74, 158, 255, 0.1)';
    ctx.fillRect(Math.min(boxStartX, boxEndX), Math.min(boxStartY, boxEndY),
        Math.abs(boxEndX - boxStartX), Math.abs(boxEndY - boxStartY));
}

function onRightClick(e) {
    e.preventDefault();
    const pos = getMousePos(e);
    const point = findNearestPoint(pos.x, pos.y);
    if (point) {
        saveHistory();
        const arr = getArrayByType(point.type);
        arr[point.index * 3 + 2] = 0;
        const idx = selectedPoints.findIndex(p => p.type === point.type && p.index === point.index);
        if (idx >= 0) selectedPoints.splice(idx, 1);
        updateUI();
        render();
        showStatus(`${point.name} 숨김`);
    }
}

function onKeyDown(e) {
    if (e.code === 'Space' && !e.repeat) {
        e.preventDefault();
        spacePressed = true;
        canvas.style.cursor = 'grab';
    }
    else if (e.ctrlKey && e.key === 'z') { e.preventDefault(); undo(); }
    else if (e.ctrlKey && e.key === 'y') { e.preventDefault(); redo(); }
    else if (e.key === 'Delete' && selectedPoints.length > 0) {
        saveHistory();
        selectedPoints.forEach(p => {
            const arr = getArrayByType(p.type);
            arr[p.index * 3 + 2] = 0;
        });
        selectedPoints = [];
        updateUI();
        render();
        showStatus('선택 항목 숨김');
    } else if (e.key === 'Escape') {
        selectedPoints = [];
        updateUI();
        render();
    }
}

function onKeyUp(e) {
    if (e.code === 'Space') {
        spacePressed = false;
        if (!isPanning) {
            canvas.style.cursor = 'crosshair';
        }
    }
}

function applyZoom() {
    const inner = document.getElementById('canvasInner');
    const wrapper = document.getElementById('canvasWrapper');
    const scaledW = canvas.width * zoom;
    const scaledH = canvas.height * zoom;
    canvas.style.width = scaledW + 'px';
    canvas.style.height = scaledH + 'px';
    inner.style.width = Math.max(scaledW, wrapper.clientWidth) + 'px';
    inner.style.height = Math.max(scaledH, wrapper.clientHeight) + 'px';
    canvas.style.marginLeft = Math.max(0, (wrapper.clientWidth - scaledW) / 2) + 'px';
    canvas.style.marginTop = Math.max(0, (wrapper.clientHeight - scaledH) / 2) + 'px';
}

function onWheel(e) {
    e.preventDefault();
    const wrapper = document.getElementById('canvasWrapper');

    // 줌 전: 마우스 아래의 캔버스 좌표를 getBoundingClientRect로 정확하게 계산
    const rect = canvas.getBoundingClientRect();
    const canvasX = (e.clientX - rect.left) * (canvas.width / rect.width);
    const canvasY = (e.clientY - rect.top) * (canvas.height / rect.height);

    // 줌 적용
    zoom = Math.max(0.25, Math.min(4, zoom * (e.deltaY > 0 ? 0.9 : 1.1)));
    applyZoom();

    // 줌 후: 동일한 캔버스 좌표가 화면상 어디에 있는지 다시 계산
    const newRect = canvas.getBoundingClientRect();
    const screenX = newRect.left + canvasX * (newRect.width / canvas.width);
    const screenY = newRect.top + canvasY * (newRect.height / canvas.height);

    // 마우스 아래로 다시 돌아오도록 스크롤 보정
    wrapper.scrollLeft += screenX - e.clientX;
    wrapper.scrollTop += screenY - e.clientY;

    document.getElementById('statusZoom').textContent = Math.round(zoom * 100) + '%';
}

// ========== 줌/캔버스 ==========
function fitCanvasToWrapper() {
    const wrapper = document.getElementById('canvasWrapper');
    const wrapperRect = wrapper.getBoundingClientRect();
    const scaleX = (wrapperRect.width - 40) / canvas.width;
    const scaleY = (wrapperRect.height - 40) / canvas.height;
    zoom = Math.min(scaleX, scaleY, 1);
    applyZoom();
    document.getElementById('statusZoom').textContent = Math.round(zoom * 100) + '%';
}

function centerCanvas() {
    const wrapper = document.getElementById('canvasWrapper');
    const scrollX = (wrapper.scrollWidth - wrapper.clientWidth) / 2;
    const scrollY = (wrapper.scrollHeight - wrapper.clientHeight) / 2;
    wrapper.scrollLeft = Math.max(0, scrollX);
    wrapper.scrollTop = Math.max(0, scrollY);
}

// 창 리사이즈 시 캔버스 중앙 유지
window.addEventListener('resize', () => {
    centerCanvas();
});

// ========== 크기 측정 헬퍼 ==========
function getFaceScale() {
    const kpts = baseFaceData || poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 48 * 3) return canvas.width / 512;

    // 두 눈 중심 사이 거리 (왼눈 36-41, 오른눈 42-47)
    let lx = 0, ly = 0, lc = 0, rx = 0, ry = 0, rc = 0;
    for (let i = 36; i <= 41; i++) {
        if (i * 3 + 2 < kpts.length && kpts[i * 3 + 2] > 0) {
            lx += kpts[i * 3]; ly += kpts[i * 3 + 1]; lc++;
        }
    }
    for (let i = 42; i <= 47; i++) {
        if (i * 3 + 2 < kpts.length && kpts[i * 3 + 2] > 0) {
            rx += kpts[i * 3]; ry += kpts[i * 3 + 1]; rc++;
        }
    }
    if (lc > 0 && rc > 0) {
        lx /= lc; ly /= lc; rx /= rc; ry /= rc;
        const eyeDist = Math.sqrt((rx - lx) ** 2 + (ry - ly) ** 2);
        if (eyeDist > 1) return eyeDist / 40;
    }
    return canvas.width / 512;
}

function getBodyScale() {
    const kpts = poseData.pose_keypoints_2d;
    if (!kpts || kpts.length < 24 * 3) return canvas.width / 512;

    // 어깨 폭 기준
    const rs = JOINT.R_SHOULDER, ls = JOINT.L_SHOULDER;
    if (kpts[rs * 3 + 2] > 0 && kpts[ls * 3 + 2] > 0) {
        const sw = Math.sqrt((kpts[rs * 3] - kpts[ls * 3]) ** 2 + (kpts[rs * 3 + 1] - kpts[ls * 3 + 1]) ** 2);
        if (sw > 1) return sw / 100;
    }

    // fallback: 목→엉덩이 거리
    const neck = JOINT.NECK, rh = JOINT.R_HIP, lh = JOINT.L_HIP;
    if (kpts[neck * 3 + 2] > 0) {
        const hipX = (kpts[rh * 3 + 2] > 0 && kpts[lh * 3 + 2] > 0) ?
            (kpts[rh * 3] + kpts[lh * 3]) / 2 : (kpts[rh * 3 + 2] > 0 ? kpts[rh * 3] : kpts[lh * 3]);
        const hipY = (kpts[rh * 3 + 2] > 0 && kpts[lh * 3 + 2] > 0) ?
            (kpts[rh * 3 + 1] + kpts[lh * 3 + 1]) / 2 : (kpts[rh * 3 + 2] > 0 ? kpts[rh * 3 + 1] : kpts[lh * 3 + 1]);
        const torso = Math.sqrt((hipX - kpts[neck * 3]) ** 2 + (hipY - kpts[neck * 3 + 1]) ** 2);
        if (torso > 1) return torso / 150;
    }

    return canvas.width / 512;
}

// ========== 시선 & 표정 ==========
let baseFaceData = null;

function saveBaseFace() {
    if (!baseFaceData && poseData.face_keypoints_2d.length > 0) {
        baseFaceData = [...poseData.face_keypoints_2d];
    }
}

function applyGaze() {
    saveBaseFace();
    if (!baseFaceData || baseFaceData.length < 68 * 3) return;

    const gazeX = parseFloat(document.getElementById('gazeX').value);
    const gazeY = parseFloat(document.getElementById('gazeY').value);
    const scale = getFaceScale();

    document.getElementById('gazeXValue').textContent = gazeX;
    document.getElementById('gazeYValue').textContent = gazeY;

    for (let i = 36; i <= 47; i++) {
        if (i * 3 + 2 < poseData.face_keypoints_2d.length) {
            poseData.face_keypoints_2d[i * 3] = baseFaceData[i * 3] + gazeX * scale;
            poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + gazeY * scale;
        }
    }

    render();
}

function applyExpression() {
    saveBaseFace();
    if (!baseFaceData || baseFaceData.length < 68 * 3) return;

    const mouthOpen = parseFloat(document.getElementById('mouthOpen').value);
    const eyeSize = parseFloat(document.getElementById('eyeClose').value);
    const scale = getFaceScale();

    document.getElementById('mouthOpenValue').textContent = mouthOpen;
    document.getElementById('eyeCloseValue').textContent = eyeSize;

    // 입: 양수=벌리기, 음수=다물기
    if (mouthOpen >= 0) {
        // 벌리기: 윗입술 올리고 아랫입술 내리기
        for (let i = 48; i < 55; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - mouthOpen * 0.3 * scale;
            }
        }
        for (let i = 54; i < 60; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + mouthOpen * 0.7 * scale;
            }
        }
        // 안쪽 입도 동기화
        for (let i = 60; i < 65; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - mouthOpen * 0.2 * scale;
            }
        }
        for (let i = 64; i < 68; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + mouthOpen * 0.5 * scale;
            }
        }
    } else {
        // 다물기: 윗입술과 아랫입술 모두 중심으로 모음
        const closeFactor = Math.abs(mouthOpen) / 10;
        // 바깥쪽 입
        for (let i = 48; i < 60; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                let mouthCenterY = 0, mc = 0;
                for (let k = 48; k < 60; k++) {
                    if (k * 3 + 1 < baseFaceData.length) { mouthCenterY += baseFaceData[k * 3 + 1]; mc++; }
                }
                mouthCenterY /= mc;
                const dy = baseFaceData[i * 3 + 1] - mouthCenterY;
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - dy * closeFactor * 0.5;
            }
        }
        // 안쪽 입
        for (let i = 60; i < 68; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                let mouthCenterY = 0, mc = 0;
                for (let k = 60; k < 68; k++) {
                    if (k * 3 + 1 < baseFaceData.length) { mouthCenterY += baseFaceData[k * 3 + 1]; mc++; }
                }
                mouthCenterY /= mc;
                const dy = baseFaceData[i * 3 + 1] - mouthCenterY;
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - dy * closeFactor * 0.7;
            }
        }
    }

    // 눈: 양수=감기, 음수=크게 뜨기
    if (eyeSize >= 0) {
        const eyeCloseAmount = eyeSize / 100 * 8 * scale;
        // 위 눈꺼풀 내리기
        [37, 38, 43, 44].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + eyeCloseAmount;
            }
        });
        // 아래 눈꺼풀 올리기
        [40, 41, 46, 47].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - eyeCloseAmount * 0.3;
            }
        });
    } else {
        const eyeOpenAmount = Math.abs(eyeSize) / 100 * 6 * scale;
        // 위 눈꺼풀 올리기
        [37, 38, 43, 44].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - eyeOpenAmount;
            }
        });
        // 아래 눈꺼풀 내리기
        [40, 41, 46, 47].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + eyeOpenAmount * 0.4;
            }
        });
    }

    render();
}

function resetExpression() {
    if (baseFaceData) {
        poseData.face_keypoints_2d = [...baseFaceData];
        baseFaceData = null;
    }
    document.getElementById('gazeX').value = 0;
    document.getElementById('gazeY').value = 0;
    document.getElementById('mouthOpen').value = 0;
    document.getElementById('eyeClose').value = 0;
    document.getElementById('gazeXValue').textContent = '0';
    document.getElementById('gazeYValue').textContent = '0';
    document.getElementById('mouthOpenValue').textContent = '0';
    document.getElementById('eyeCloseValue').textContent = '0';
    render();
    showStatus('표정 초기화');
}

// ========== FK 관절 회전 ==========
let fkBasePose = null;
let fkLastAngles = {};

function ensureFKBase() {
    if (!fkBasePose) {
        fkBasePose = {
            body: [...poseData.pose_keypoints_2d],
            leftHand: [...poseData.hand_left_keypoints_2d],
            rightHand: [...poseData.hand_right_keypoints_2d],
            face: [...poseData.face_keypoints_2d]
        };
        fkLastAngles = {};
    }
}

function restoreFKBase() {
    if (fkBasePose) {
        poseData.pose_keypoints_2d = [...fkBasePose.body];
        poseData.hand_left_keypoints_2d = [...fkBasePose.leftHand];
        poseData.hand_right_keypoints_2d = [...fkBasePose.rightHand];
        poseData.face_keypoints_2d = [...fkBasePose.face];
    }
}

function applyAllFK() {
    ensureFKBase();
    restoreFKBase();

    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 24 * 3) { render(); return; }

    // Head
    const headAngle = parseFloat(document.getElementById('fkHead').value);
    if (headAngle !== 0) {
        const neckX = kpts[JOINT.NECK * 3];
        const neckY = kpts[JOINT.NECK * 3 + 1];
        const rad = headAngle * Math.PI / 180;
        const cos = Math.cos(rad), sin = Math.sin(rad);
        [JOINT.NOSE, JOINT.R_EYE, JOINT.L_EYE, JOINT.R_EAR, JOINT.L_EAR].forEach(j => {
            const x = kpts[j * 3] - neckX;
            const y = kpts[j * 3 + 1] - neckY;
            kpts[j * 3] = neckX + x * cos - y * sin;
            kpts[j * 3 + 1] = neckY + x * sin + y * cos;
        });
        rotateFaceAroundPivot(neckX, neckY, cos, sin);
    }

    // Both arms
    ['right', 'left'].forEach(side => {
        const prefix = side === 'right' ? 'R' : 'L';
        const shoulderAngle = parseFloat(document.getElementById(`fk${prefix}Shoulder`).value);
        const elbowAngle = parseFloat(document.getElementById(`fk${prefix}Elbow`).value);
        const wristAngle = parseFloat(document.getElementById(`fk${prefix}Wrist`).value);

        const SHOULDER = side === 'right' ? JOINT.R_SHOULDER : JOINT.L_SHOULDER;
        const ELBOW = side === 'right' ? JOINT.R_ELBOW : JOINT.L_ELBOW;
        const WRIST = side === 'right' ? JOINT.R_WRIST : JOINT.L_WRIST;

        if (shoulderAngle !== 0) {
            const pivotX = kpts[SHOULDER * 3];
            const pivotY = kpts[SHOULDER * 3 + 1];
            const rad = shoulderAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            [ELBOW, WRIST].forEach(j => {
                const x = kpts[j * 3] - pivotX;
                const y = kpts[j * 3 + 1] - pivotY;
                kpts[j * 3] = pivotX + x * cos - y * sin;
                kpts[j * 3 + 1] = pivotY + x * sin + y * cos;
            });
            rotateHandAroundPivot(side, pivotX, pivotY, cos, sin);
        }

        if (elbowAngle !== 0) {
            const pivotX = kpts[ELBOW * 3];
            const pivotY = kpts[ELBOW * 3 + 1];
            const rad = elbowAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            const x = kpts[WRIST * 3] - pivotX;
            const y = kpts[WRIST * 3 + 1] - pivotY;
            kpts[WRIST * 3] = pivotX + x * cos - y * sin;
            kpts[WRIST * 3 + 1] = pivotY + x * sin + y * cos;
            rotateHandAroundPivot(side, pivotX, pivotY, cos, sin);
        }

        if (wristAngle !== 0) {
            const pivotX = kpts[WRIST * 3];
            const pivotY = kpts[WRIST * 3 + 1];
            const rad = wristAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            rotateHandAroundPivot(side, pivotX, pivotY, cos, sin);
        }
    });

    // Both legs
    ['right', 'left'].forEach(side => {
        const prefix = side === 'right' ? 'R' : 'L';
        const hipAngle = parseFloat(document.getElementById(`fk${prefix}Hip`).value);
        const kneeAngle = parseFloat(document.getElementById(`fk${prefix}Knee`).value);

        const HIP = side === 'right' ? JOINT.R_HIP : JOINT.L_HIP;
        const KNEE = side === 'right' ? JOINT.R_KNEE : JOINT.L_KNEE;
        const ANKLE = side === 'right' ? JOINT.R_ANKLE : JOINT.L_ANKLE;
        const FOOT = side === 'right'
            ? [JOINT.R_BIGTOE, JOINT.R_SMALLTOE, JOINT.R_HEEL]
            : [JOINT.L_BIGTOE, JOINT.L_SMALLTOE, JOINT.L_HEEL];

        if (hipAngle !== 0) {
            const pivotX = kpts[HIP * 3];
            const pivotY = kpts[HIP * 3 + 1];
            const rad = hipAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            [KNEE, ANKLE, ...FOOT].forEach(j => {
                if (j * 3 + 2 >= kpts.length) return;
                const x = kpts[j * 3] - pivotX;
                const y = kpts[j * 3 + 1] - pivotY;
                kpts[j * 3] = pivotX + x * cos - y * sin;
                kpts[j * 3 + 1] = pivotY + x * sin + y * cos;
            });
        }

        if (kneeAngle !== 0) {
            const pivotX = kpts[KNEE * 3];
            const pivotY = kpts[KNEE * 3 + 1];
            const rad = kneeAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            [ANKLE, ...FOOT].forEach(j => {
                if (j * 3 + 2 >= kpts.length) return;
                const x = kpts[j * 3] - pivotX;
                const y = kpts[j * 3 + 1] - pivotY;
                kpts[j * 3] = pivotX + x * cos - y * sin;
                kpts[j * 3 + 1] = pivotY + x * sin + y * cos;
            });
        }
    });

    render();
}

function applyFKHead() {
    document.getElementById('fkHeadValue').textContent = document.getElementById('fkHead').value + '°';
    applyAllFK();
}

function applyFKArm(side) {
    const prefix = side === 'right' ? 'R' : 'L';
    document.getElementById(`fk${prefix}ShoulderValue`).textContent = document.getElementById(`fk${prefix}Shoulder`).value + '°';
    document.getElementById(`fk${prefix}ElbowValue`).textContent = document.getElementById(`fk${prefix}Elbow`).value + '°';
    document.getElementById(`fk${prefix}WristValue`).textContent = document.getElementById(`fk${prefix}Wrist`).value + '°';
    applyAllFK();
}

function applyFKLeg(side) {
    const prefix = side === 'right' ? 'R' : 'L';
    document.getElementById(`fk${prefix}HipValue`).textContent = document.getElementById(`fk${prefix}Hip`).value + '°';
    document.getElementById(`fk${prefix}KneeValue`).textContent = document.getElementById(`fk${prefix}Knee`).value + '°';
    applyAllFK();
}

function resetFK() {
    if (fkBasePose) {
        poseData.pose_keypoints_2d = [...fkBasePose.body];
        poseData.hand_left_keypoints_2d = [...fkBasePose.leftHand];
        poseData.hand_right_keypoints_2d = [...fkBasePose.rightHand];
        poseData.face_keypoints_2d = [...fkBasePose.face];
    }

    ['fkHead', 'fkRShoulder', 'fkRElbow', 'fkRWrist',
     'fkLShoulder', 'fkLElbow', 'fkLWrist',
     'fkRHip', 'fkRKnee', 'fkLHip', 'fkLKnee'].forEach(id => {
        document.getElementById(id).value = 0;
        document.getElementById(id + 'Value').textContent = '0°';
    });

    render();
    showStatus('관절 초기화');
}

// ========== 손 프리셋 ==========

// 1단계: 프리셋 원본 복원 시스템
function ensureHandBase(side) {
    const key = side === 'left' ? 'left' : 'right';
    if (!handPresetBase[key]) {
        const kpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
        if (kpts && kpts.length >= 3) {
            handPresetBase[key] = [...kpts];
        }
    }
}

function restoreHandBase(side) {
    const key = side === 'left' ? 'left' : 'right';
    if (handPresetBase[key]) {
        if (side === 'left') {
            poseData.hand_left_keypoints_2d = [...handPresetBase[key]];
        } else {
            poseData.hand_right_keypoints_2d = [...handPresetBase[key]];
        }
    }
}

function resetHandPreset() {
    if (handPresetBase.left) {
        poseData.hand_left_keypoints_2d = [...handPresetBase.left];
        handPresetBase.left = null;
    }
    if (handPresetBase.right) {
        poseData.hand_right_keypoints_2d = [...handPresetBase.right];
        handPresetBase.right = null;
    }
    render();
    updateUI();
    showStatus('손 프리셋 초기화');
}

// 2단계: getHandScale 개선
function getHandScale(side) {
    const key = side === 'left' ? 'left' : 'right';
    const kpts = handPresetBase[key] ||
        (side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d);
    if (!kpts || kpts.length < 13 * 3) return Math.max(0.3, Math.min(canvas.width / 512, 5));

    // 손목→중지끝(12) 거리 우선
    if (kpts[0 * 3 + 2] > 0 && kpts[12 * 3 + 2] > 0) {
        const dx = kpts[12 * 3] - kpts[0 * 3];
        const dy = kpts[12 * 3 + 1] - kpts[0 * 3 + 1];
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 1) return Math.max(0.3, Math.min(dist / 50, 5));
    }

    // 손목→중지MCP(9) 거리
    if (kpts[0 * 3 + 2] > 0 && kpts[9 * 3 + 2] > 0) {
        const dx = kpts[9 * 3] - kpts[0 * 3];
        const dy = kpts[9 * 3 + 1] - kpts[0 * 3 + 1];
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 1) return Math.max(0.3, Math.min(dist / 18, 5));
    }

    return Math.max(0.3, Math.min(canvas.width / 512, 5));
}

// 4단계: 손바닥/손등 방향 감지
function detectCurlSign(kpts, side) {
    if (!kpts || kpts.length < 10 * 3) {
        return side === 'right' ? 1 : -1;
    }

    const wristX = kpts[0 * 3], wristY = kpts[0 * 3 + 1];

    // 중지MCP(9)로 midDir 벡터
    if (kpts[9 * 3 + 2] <= 0 || kpts[0 * 3 + 2] <= 0) {
        return side === 'right' ? 1 : -1;
    }
    const vec1x = kpts[9 * 3] - wristX;
    const vec1y = kpts[9 * 3 + 1] - wristY;

    // 엄지CMC(1)로 엄지 벡터
    if (kpts[1 * 3 + 2] <= 0) {
        return side === 'right' ? 1 : -1;
    }
    const vec2x = kpts[1 * 3] - wristX;
    const vec2y = kpts[1 * 3 + 1] - wristY;

    const cross = vec1x * vec2y - vec1y * vec2x;

    // 오른손: cross > 0 → 손바닥(양수), cross < 0 → 손등(음수)
    // 왼손: 반대
    if (side === 'right') {
        return cross >= 0 ? 1 : -1;
    } else {
        return cross >= 0 ? -1 : 1;
    }
}

function applyHandPreset(which, preset) {
    const hands = which === 'both' ? ['left', 'right'] : [which];
    saveHistory();

    hands.forEach(side => {
        // 1단계: base 저장 후 복원
        ensureHandBase(side);
        restoreHandBase(side);

        const kpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
        if (!kpts || kpts.length < 3) return;

        // 2단계: 스케일 계산 (항상 base에서)
        const scale = getHandScale(side);
        const wristX = kpts[0 * 3];
        const wristY = kpts[0 * 3 + 1];

        // 4단계: curl 방향 감지 (base 데이터에서)
        const baseKpts = handPresetBase[side] || kpts;
        const curlSign = detectCurlSign(baseKpts, side);

        const midDir = kpts[9 * 3 + 2] > 0 ?
            Math.atan2(kpts[9 * 3 + 1] - wristY, kpts[9 * 3] - wristX) :
            (side === 'left' ? Math.PI / 2 : -Math.PI / 2);

        const fingers = [
            { start: 1, joints: 4, angleOffset: -60, name: 'thumb' },
            { start: 5, joints: 4, angleOffset: -15, name: 'index' },
            { start: 9, joints: 4, angleOffset: 0, name: 'middle' },
            { start: 13, joints: 4, angleOffset: 15, name: 'ring' },
            { start: 17, joints: 4, angleOffset: 35, name: 'pinky' }
        ];

        // 5단계: curl 값 강화
        const curlSettings = {
            open: { thumb: 5, index: 3, middle: 3, ring: 3, pinky: 5 },
            fist: { thumb: 100, index: 150, middle: 150, ring: 150, pinky: 150 },
            point: { thumb: 100, index: 0, middle: 150, ring: 150, pinky: 150 },
            peace: { thumb: 100, index: 0, middle: 0, ring: 150, pinky: 150 },
            ok: { thumb: 50, index: 50, middle: 0, ring: 0, pinky: 0 },
            thumbup: { thumb: 0, index: 150, middle: 150, ring: 150, pinky: 150 }
        };

        const curls = curlSettings[preset] || curlSettings.open;

        // 3단계: 관절별 가중치
        const jointWeights = [0.9, 1.2, 0.8, 0.3]; // MCP, PIP, DIP, tip

        const baseLengths = { thumb: [12, 10, 8, 6], other: [18, 14, 10, 8] };

        fingers.forEach(finger => {
            let baseAngle = midDir + (finger.angleOffset * Math.PI / 180);
            const rawCurl = curls[finger.name] * Math.PI / 180;
            // 4단계: curl 방향에 curlSign 적용
            const curl = rawCurl * curlSign;

            let prevX = wristX;
            let prevY = wristY;
            let currentAngle = baseAngle;

            if (finger.name === 'thumb') {
                if (preset === 'thumbup') {
                    currentAngle = midDir - (Math.PI / 2) * curlSign;
                }
                const thumbOffsetAngle = (preset === 'thumbup') ?
                    midDir - (Math.PI / 3) * curlSign :
                    baseAngle + (Math.PI / 6) * curlSign;
                prevX = wristX + Math.cos(thumbOffsetAngle) * 15 * scale;
                prevY = wristY + Math.sin(thumbOffsetAngle) * 15 * scale;
            }

            const lengths = finger.name === 'thumb' ? baseLengths.thumb : baseLengths.other;

            for (let j = 0; j < finger.joints; j++) {
                const idx = finger.start + j;
                if (idx * 3 + 2 >= kpts.length) continue;

                // 3단계: 관절별 가중치 차등 적용
                currentAngle += curl * 0.45 * jointWeights[j];

                const len = (lengths[j] || 10) * scale;
                kpts[idx * 3] = prevX + Math.cos(currentAngle) * len;
                kpts[idx * 3 + 1] = prevY + Math.sin(currentAngle) * len;
                kpts[idx * 3 + 2] = 1.0;

                prevX = kpts[idx * 3];
                prevY = kpts[idx * 3 + 1];
            }
        });

        // ok: 엄지와 검지 끝이 만나도록 특별 처리
        if (preset === 'ok') {
            const thumbTip = 4, indexTip = 8;
            if (thumbTip * 3 + 2 < kpts.length && indexTip * 3 + 2 < kpts.length) {
                const meetX = (kpts[thumbTip * 3] + kpts[indexTip * 3]) / 2;
                const meetY = (kpts[thumbTip * 3 + 1] + kpts[indexTip * 3 + 1]) / 2;
                kpts[thumbTip * 3] = meetX;
                kpts[thumbTip * 3 + 1] = meetY;
                kpts[indexTip * 3] = meetX;
                kpts[indexTip * 3 + 1] = meetY;
            }
        }
    });

    render();
    updateUI();
    showStatus(`손 프리셋: ${preset}`);
}

// ========== 머리 이식 프리셋 ==========
// 실제 참조 이미지에서 DWPose로 추출 → Neck 기준 정규화
// norm = (kp - neck) / nose_neck_distance

const HEAD_PRESETS = {
    "정면": {
        label: "정면",
        body_head: {
            0: [-0.06186, -0.99808, 0.833],
            14: [-0.27633, -1.2043, 0.842],
            15: [0.1526, -1.25379, 0.841],
            16: [-0.4743, -1.06407, 0.715],
            17: [0.52379, -1.17131, 0.738],
        },
        face_68: [
            [-0.46605,-1.1878,0.941], [-0.44955,-1.06407,0.949], [-0.4248,-0.94034,0.988], [-0.37531,-0.81661,0.979],
            [-0.33407,-0.70938,0.96], [-0.25158,-0.6104,0.935], [-0.16085,-0.53616,1.003], [-0.04537,-0.48667,0.999],
            [0.07836,-0.49492,1.001], [0.19384,-0.53616,0.985], [0.29283,-0.60215,0.999], [0.37531,-0.70113,0.967],
            [0.43305,-0.80837,1.0], [0.46605,-0.92385,1.016], [0.4743,-1.04758,0.991], [0.48255,-1.17955,1.006],
            [0.4743,-1.30328,1.024], [-0.4413,-1.27854,0.995], [-0.39181,-1.31153,1.024], [-0.32582,-1.31978,1.003],
            [-0.25983,-1.31978,0.992], [-0.18559,-1.31153,0.98], [0.00412,-1.34453,1.015], [0.07836,-1.36927,1.01],
            [0.16085,-1.39402,0.988], [0.24333,-1.40227,0.988], [0.31757,-1.37752,1.02], [-0.08661,-1.21255,1.02],
            [-0.07836,-1.13006,1.004], [-0.07836,-1.04758,1.008], [-0.07836,-0.97334,1.015], [-0.1361,-0.89085,0.991],
            [-0.09486,-0.89085,0.987], [-0.04537,-0.89085,1.006], [0.00412,-0.90735,1.028], [0.05362,-0.9156,1.022],
            [-0.35882,-1.17955,1.003], [-0.30108,-1.22905,0.982], [-0.23509,-1.22905,0.976], [-0.17735,-1.17955,0.993],
            [-0.23509,-1.15481,0.973], [-0.30108,-1.14656,0.976], [0.05362,-1.21255,1.004], [0.10311,-1.27029,1.007],
            [0.17735,-1.28679,1.013], [0.25158,-1.26204,1.023], [0.19384,-1.21255,1.006], [0.11961,-1.2043,0.996],
            [-0.1691,-0.74238,0.974], [-0.11961,-0.77537,1.005], [-0.07011,-0.79187,1.006], [-0.02887,-0.80012,1.014],
            [0.00412,-0.80837,1.021], [0.09486,-0.80012,1.013], [0.17735,-0.78362,0.994], [0.11961,-0.74238,1.002],
            [0.06186,-0.70938,0.998], [-0.01237,-0.69289,0.999], [-0.07011,-0.69289,0.992], [-0.11961,-0.70938,0.99],
            [-0.1526,-0.74238,0.987], [-0.08661,-0.75063,1.002], [-0.02062,-0.75887,1.012], [0.06186,-0.76712,1.018],
            [0.1526,-0.77537,1.001], [0.07011,-0.76712,1.015], [-0.02062,-0.75887,1.008], [-0.08661,-0.75063,1.002]
        ]
    },
    "살짝돌림": {
        label: "살짝 오른쪽",
        body_head: {
            0: [0.27723, -0.9608, 0.838],
            14: [0.04177, -1.15828, 0.867],
            15: [0.42154, -1.17347, 0.886],
            16: [-0.30001, -0.99878, 0.739],
            17: [0.60383, -1.06714, 0.687],
        },
        face_68: [
            [-0.28482,-1.1279,0.958], [-0.26204,-1.01397,0.941], [-0.23925,-0.90004,0.949], [-0.20887,-0.79371,0.944],
            [-0.1557,-0.68737,0.945], [-0.07975,-0.61142,0.951], [0.0038,-0.53547,0.999], [0.11013,-0.4899,0.976],
            [0.22406,-0.47471,0.967], [0.33799,-0.4899,0.995], [0.42913,-0.55066,0.989], [0.49749,-0.6418,0.955],
            [0.54306,-0.74054,0.989], [0.57344,-0.85447,0.999], [0.58863,-0.9684,0.972], [0.58863,-1.08233,0.971],
            [0.58104,-1.20385,0.991], [-0.12532,-1.22664,0.992], [-0.05696,-1.25702,0.988], [0.01139,-1.26462,0.992],
            [0.08735,-1.26462,0.996], [0.1557,-1.24943,0.984], [0.3304,-1.26462,0.985], [0.38356,-1.2874,0.969],
            [0.43673,-1.30259,0.973], [0.49749,-1.30259,0.98], [0.55066,-1.27981,0.964], [0.25444,-1.15828,1.026],
            [0.26204,-1.08233,1.003], [0.27723,-1.01397,0.999], [0.28482,-0.94561,1.006], [0.17849,-0.86966,0.98],
            [0.23166,-0.86207,0.982], [0.27723,-0.86207,0.989], [0.3228,-0.86966,0.997], [0.35318,-0.88485,0.994],
            [-0.05696,-1.1355,0.99], [0.0038,-1.17347,1.029], [0.07975,-1.18107,1.006], [0.13292,-1.1355,0.996],
            [0.07216,-1.11271,0.998], [0.0038,-1.10511,0.994], [0.33799,-1.14309,1.027], [0.37597,-1.19626,1.049],
            [0.44432,-1.20385,1.048], [0.49749,-1.17347,1.039], [0.45192,-1.1355,1.03], [0.39116,-1.1279,1.031],
            [0.10254,-0.71775,1.002], [0.17089,-0.74814,0.98], [0.24685,-0.77092,0.948], [0.28482,-0.77092,0.951],
            [0.3152,-0.77092,0.961], [0.36837,-0.76333,0.967], [0.41394,-0.74054,0.972], [0.37597,-0.70256,0.976],
            [0.3304,-0.67978,0.965], [0.27723,-0.67218,0.953], [0.21647,-0.67218,0.957], [0.1557,-0.68737,0.985],
            [0.11773,-0.71775,1.005], [0.20128,-0.72535,0.981], [0.27723,-0.73295,0.966], [0.33799,-0.73295,0.975],
            [0.39116,-0.73295,0.972], [0.33799,-0.73295,0.976], [0.27723,-0.72535,0.967], [0.20128,-0.71775,0.976]
        ]
    },
    "3/4뷰": {
        label: "3/4 오른쪽",
        body_head: {
            0: [0.48401, -0.87506, 0.83],
            14: [0.25963, -1.0161, 0.869],
            15: [0.49683, -1.04174, 0.871],
            16: [-0.16988, -0.85583, 0.732],
            17: [0.53529, -0.97763, 0.548],
        },
        face_68: [
            [-0.14424,-0.96481,0.965], [-0.12501,-0.86865,0.942], [-0.09937,-0.7789,0.957], [-0.0609,-0.68915,0.996],
            [-0.01603,-0.60581,0.993], [0.0609,-0.54812,0.989], [0.13783,-0.50324,1.006], [0.23399,-0.4776,0.969],
            [0.32374,-0.45196,0.981], [0.4199,-0.45196,1.008], [0.49683,-0.49683,0.976], [0.52247,-0.58017,0.952],
            [0.54171,-0.67633,0.977], [0.55453,-0.76608,0.959], [0.56094,-0.86224,0.95], [0.54812,-0.9584,0.948],
            [0.53529,-1.05456,0.94], [0.12501,-1.0738,0.97], [0.18271,-1.10585,0.988], [0.24681,-1.11867,1.005],
            [0.31092,-1.11867,0.998], [0.36862,-1.11226,0.97], [0.47119,-1.10585,0.949], [0.49042,-1.11867,0.956],
            [0.50965,-1.13149,0.953], [0.52888,-1.1379,0.937], [0.54812,-1.12508,0.922], [0.43272,-1.02892,1.057],
            [0.46478,-0.97763,1.029], [0.49042,-0.91994,1.005], [0.52247,-0.86865,0.989], [0.40067,-0.78531,0.986],
            [0.43913,-0.78531,0.994], [0.48401,-0.78531,0.979], [0.51606,-0.79172,0.979], [0.53529,-0.81096,0.978],
            [0.17629,-1.00328,0.992], [0.22758,-1.02892,1.032], [0.27887,-1.04174,1.026], [0.32374,-1.00328,1.023],
            [0.27246,-0.98405,1.01], [0.22758,-0.98405,1.009], [0.45837,-1.0161,1.024], [0.4776,-1.04815,1.013],
            [0.50965,-1.05456,0.98], [0.52888,-1.03533,0.992], [0.50965,-1.00969,0.997], [0.48401,-1.00969,1.008],
            [0.33656,-0.6571,0.961], [0.40708,-0.68274,0.99], [0.47119,-0.70838,0.989], [0.49683,-0.70838,0.982],
            [0.51606,-0.70838,0.974], [0.52888,-0.69556,0.975], [0.52888,-0.67633,0.949], [0.52888,-0.65069,0.937],
            [0.51606,-0.63146,0.936], [0.49683,-0.61863,0.941], [0.43913,-0.62504,0.952], [0.38785,-0.63787,0.962],
            [0.34938,-0.6571,0.968], [0.4199,-0.66351,0.974], [0.49042,-0.66992,0.954], [0.50965,-0.66992,0.952],
            [0.52247,-0.66992,0.948], [0.50965,-0.66992,0.954], [0.49042,-0.66992,0.951], [0.4199,-0.66351,0.965]
        ]
    },
    "프로필": {
        label: "우측 프로필",
        body_head: {
            0: [0.58096, -0.81393, 0.837],
            14: [0.38632, -0.95549, 0.917],
            15: [0.55147, -0.95549, 0.818],
            16: [-0.06193, -0.82573, 0.704],
            17: [0.4689, -0.84342, 0.318],
        },
        face_68: [
            [-0.03244,-0.9142,0.975], [-0.01475,-0.83163,0.975], [0.00885,-0.74316,0.972], [0.03834,-0.66058,1.03],
            [0.07962,-0.58391,1.004], [0.1504,-0.53083,0.991], [0.22118,-0.48954,0.975], [0.30375,-0.46005,0.977],
            [0.38632,-0.43646,0.972], [0.47479,-0.42466,0.971], [0.54557,-0.46595,0.969], [0.56327,-0.54262,0.972],
            [0.58096,-0.63109,0.99], [0.58686,-0.70777,0.964], [0.58096,-0.79624,0.946], [0.56916,-0.87881,0.938],
            [0.55737,-0.96138,0.943], [0.28606,-1.01447,0.972], [0.33324,-1.03806,0.994], [0.38632,-1.04396,1.001],
            [0.43351,-1.04396,0.99], [0.48069,-1.03216,0.952], [0.53967,-1.02036,0.916], [0.54557,-1.02036,0.92],
            [0.55147,-1.02626,0.92], [0.55737,-1.02626,0.903], [0.56916,-1.02036,0.888], [0.52198,-0.95549,0.989],
            [0.55737,-0.9083,1.007], [0.59276,-0.86112,0.989], [0.62814,-0.80803,0.999], [0.50428,-0.73726,0.958],
            [0.53967,-0.73726,0.97], [0.56916,-0.73726,0.968], [0.60455,-0.74316,0.985], [0.62814,-0.76675,0.994],
            [0.32144,-0.94369,1.017], [0.35683,-0.96728,1.015], [0.39812,-0.97318,1.014], [0.42761,-0.94369,1.035],
            [0.39222,-0.926,1.045], [0.35683,-0.93189,1.046], [0.53377,-0.94959,0.988], [0.53967,-0.96138,0.978],
            [0.55147,-0.96138,0.944], [0.55737,-0.94959,0.95], [0.55147,-0.94369,0.96], [0.53967,-0.94369,0.974],
            [0.4571,-0.6193,0.957], [0.51018,-0.64289,0.973], [0.56327,-0.66648,0.973], [0.58096,-0.66058,0.979],
            [0.58686,-0.66058,0.981], [0.58686,-0.64289,0.997], [0.57506,-0.63109,0.96], [0.58096,-0.6134,0.959],
            [0.58096,-0.5957,0.956], [0.56916,-0.58391,0.946], [0.52788,-0.58981,0.929], [0.49249,-0.6016,0.954],
            [0.463,-0.6193,0.961], [0.51608,-0.62519,0.959], [0.56916,-0.63109,0.964], [0.56916,-0.63109,0.967],
            [0.57506,-0.63109,0.96], [0.56916,-0.63109,0.965], [0.56327,-0.63109,0.954], [0.51608,-0.62519,0.952]
        ]
    },
    "살짝숙임": {
        label: "살짝 아래",
        body_head: {
            0: [-0.13392, -0.99099, 0.791],
            14: [-0.40175, -1.25883, 0.826],
            15: [0.13392, -1.3124, 0.815],
            16: [-0.64816, -1.30168, 0.674],
            17: [0.65888, -1.45167, 0.736],
        },
        face_68: [
            [-0.61602,-1.33382,0.944], [-0.58388,-1.18383,0.974], [-0.55174,-1.02313,0.96], [-0.47675,-0.88386,0.959],
            [-0.40175,-0.74458,0.954], [-0.29462,-0.61602,0.918], [-0.18749,-0.50889,0.988], [-0.04821,-0.43389,0.992],
            [0.10178,-0.44461,0.996], [0.24105,-0.50889,0.975], [0.3589,-0.62674,0.975], [0.46603,-0.74458,0.94],
            [0.53031,-0.89457,0.968], [0.57317,-1.04456,0.964], [0.58388,-1.21597,0.997], [0.5946,-1.37668,0.981],
            [0.58388,-1.53738,0.993], [-0.60531,-1.3981,0.956], [-0.53031,-1.41953,0.973], [-0.46603,-1.40882,0.973],
            [-0.39104,-1.3981,0.965], [-0.31605,-1.38739,0.938], [-0.06964,-1.43024,0.962], [0.02678,-1.46238,0.978],
            [0.1232,-1.49452,0.986], [0.23034,-1.51595,0.975], [0.33747,-1.50524,0.988], [-0.17677,-1.25883,1.011],
            [-0.16606,-1.15169,1.012], [-0.15534,-1.04456,0.996], [-0.15534,-0.93743,0.999], [-0.23034,-0.88386,0.971],
            [-0.17677,-0.86243,0.995], [-0.11249,-0.86243,1.008], [-0.04821,-0.88386,1.017], [0.01607,-0.90528,1.029],
            [-0.49817,-1.22669,1.004], [-0.42318,-1.21597,0.963], [-0.3589,-1.22669,0.956], [-0.29462,-1.24811,0.98],
            [-0.3589,-1.22669,0.992], [-0.43389,-1.21597,1.011], [0.01607,-1.28026,1.046], [0.10178,-1.28026,1.005],
            [0.17677,-1.28026,0.991], [0.26248,-1.3124,1.003], [0.17677,-1.28026,1.015], [0.10178,-1.26954,1.026],
            [-0.24105,-0.73387,0.97], [-0.18749,-0.74458,1.003], [-0.13392,-0.7553,1.008], [-0.09106,-0.7553,1.014],
            [-0.04821,-0.7553,1.02], [0.06964,-0.76601,1.016], [0.17677,-0.7553,0.984], [0.10178,-0.70173,1.007],
            [0.02678,-0.65888,1.011], [-0.05892,-0.63745,1.01], [-0.1232,-0.64816,1.001], [-0.18749,-0.69102,1.009],
            [-0.21963,-0.72316,0.986], [-0.15534,-0.71244,1.008], [-0.08035,-0.71244,1.017], [0.0375,-0.72316,1.022],
            [0.15534,-0.7553,0.995], [0.0375,-0.73387,1.021], [-0.06964,-0.71244,1.013], [-0.15534,-0.71244,1.009]
        ]
    },
    "많이숙임": {
        label: "많이 아래",
        body_head: {
            0: [0.0, -1.0, 0.811],
            14: [-0.37762, -1.39161, 0.823],
            15: [0.36364, -1.41958, 0.849],
            16: [-0.7972, -1.64336, 0.688],
            17: [0.93706, -1.71329, 0.68],
        },
        face_68: [
            [-0.74126,-1.62937,0.885], [-0.6993,-1.43357,0.897], [-0.65734,-1.23776,0.936], [-0.57343,-1.04196,0.927],
            [-0.46154,-0.86014,0.939], [-0.32168,-0.70629,0.904], [-0.18182,-0.55245,0.995], [-0.01399,-0.42657,0.987],
            [0.18182,-0.41259,0.983], [0.36364,-0.48252,0.98], [0.51748,-0.62238,0.973], [0.64336,-0.79021,0.962],
            [0.75524,-0.97203,0.94], [0.81119,-1.16783,0.91], [0.85315,-1.37762,0.919], [0.86713,-1.58741,0.947],
            [0.85315,-1.7972,0.934], [-0.65734,-1.58741,0.968], [-0.55944,-1.6014,0.973], [-0.44755,-1.57343,0.955],
            [-0.33566,-1.53147,0.958], [-0.23776,-1.51748,0.97], [0.11189,-1.53147,0.995], [0.23776,-1.57343,0.99],
            [0.36364,-1.61538,0.99], [0.5035,-1.65734,1.007], [0.62937,-1.65734,1.02], [-0.04196,-1.36364,1.013],
            [-0.02797,-1.20979,1.029], [-0.02797,-1.05594,1.018], [-0.01399,-0.91608,1.012], [-0.13986,-0.88811,0.986],
            [-0.06993,-0.84615,1.012], [0.01399,-0.83217,1.013], [0.11189,-0.86014,1.013], [0.18182,-0.9021,1.008],
            [-0.51748,-1.37762,0.96], [-0.41958,-1.34965,0.921], [-0.32168,-1.34965,0.941], [-0.23776,-1.36364,0.98],
            [-0.32168,-1.34965,0.966], [-0.41958,-1.34965,0.956], [0.1958,-1.39161,1.011], [0.30769,-1.37762,0.971],
            [0.40559,-1.37762,0.953], [0.51748,-1.43357,0.995], [0.41958,-1.37762,0.984], [0.30769,-1.36364,0.993],
            [-0.1958,-0.74825,0.956], [-0.11189,-0.74825,0.986], [-0.01399,-0.73427,0.989], [0.04196,-0.73427,0.991],
            [0.0979,-0.73427,0.992], [0.22378,-0.74825,0.97], [0.36364,-0.76224,0.945], [0.27972,-0.69231,0.944],
            [0.18182,-0.63636,0.973], [0.05594,-0.62238,0.998], [-0.04196,-0.63636,0.993], [-0.12587,-0.69231,0.985],
            [-0.16783,-0.73427,0.964], [-0.06993,-0.70629,0.978], [0.04196,-0.69231,0.99], [0.1958,-0.70629,0.967],
            [0.33566,-0.74825,0.947], [0.1958,-0.70629,0.958], [0.05594,-0.69231,0.986], [-0.06993,-0.70629,0.985]
        ]
    },
    "살짝올림": {
        label: "살짝 위",
        body_head: {
            0: [0.03253, -0.99947, 0.842],
            14: [-0.15081, -1.07044, 0.875],
            15: [0.16264, -1.12367, 0.885],
            16: [-0.30457, -0.81022, 0.697],
            17: [0.37554, -0.91667, 0.651],
        },
        face_68: [
            [-0.3164,-0.9285,0.908], [-0.29274,-0.85162,0.917], [-0.275,-0.77474,0.896], [-0.23952,-0.69786,0.916],
            [-0.19812,-0.6328,0.912], [-0.13898,-0.5914,0.931], [-0.0621,-0.56183,0.986], [0.0207,-0.56183,1.0],
            [0.1035,-0.56775,0.961], [0.18038,-0.58549,0.957], [0.25726,-0.61506,1.009], [0.3164,-0.66237,0.978],
            [0.35188,-0.73334,0.953], [0.36963,-0.81022,0.942], [0.36371,-0.89302,0.923], [0.3578,-0.97581,0.869],
            [0.34006,-1.0527,0.829], [-0.26909,-1.0941,0.958], [-0.22769,-1.13549,0.968], [-0.18038,-1.15915,0.964],
            [-0.12715,-1.16506,0.996], [-0.07393,-1.17098,0.99], [0.0621,-1.19463,1.004], [0.10941,-1.21238,0.984],
            [0.15672,-1.21829,0.984], [0.20995,-1.21238,1.006], [0.25726,-1.18872,1.0], [0.00887,-1.0941,1.053],
            [0.0207,-1.06453,1.061], [0.02661,-1.03496,1.05], [0.03253,-1.00538,1.015], [-0.02661,-0.90485,1.042],
            [0.00887,-0.91667,1.041], [0.04436,-0.92259,1.026], [0.07984,-0.9285,1.028], [0.10941,-0.9285,1.017],
            [-0.20995,-1.03496,0.966], [-0.17446,-1.07635,0.958], [-0.12124,-1.08818,0.993], [-0.07393,-1.05861,1.006],
            [-0.11532,-1.03496,0.99], [-0.16264,-1.02313,0.964], [0.09167,-1.0941,1.007], [0.12715,-1.13549,0.997],
            [0.18038,-1.14141,1.018], [0.22769,-1.11184,1.016], [0.18629,-1.08818,1.022], [0.13898,-1.08227,1.006],
            [-0.0621,-0.76291,0.972], [-0.0207,-0.81022,1.003], [0.03253,-0.84571,1.008], [0.05618,-0.85162,1.002],
            [0.07984,-0.85753,0.996], [0.13898,-0.83979,0.978], [0.19221,-0.80431,0.964], [0.15081,-0.78657,0.96],
            [0.10941,-0.78065,0.958], [0.06801,-0.77474,0.974], [0.02661,-0.76882,0.991], [-0.01479,-0.76291,0.989],
            [-0.04436,-0.76882,0.977], [0.00296,-0.79839,0.994], [0.0621,-0.81614,0.987], [0.12124,-0.81614,0.963],
            [0.17446,-0.80431,0.96], [0.11532,-0.81614,0.961], [0.0621,-0.81614,0.976], [0.00887,-0.79839,0.978]
        ]
    },
    "많이올림": {
        label: "많이 위",
        body_head: {
            0: [0.02742, -0.99962, 0.844],
            14: [-0.11716, -1.00461, 0.871],
            15: [0.14708, -1.02455, 0.894],
            16: [-0.25676, -0.6955, 0.608],
            17: [0.30662, -0.72541, 0.578],
        },
        face_68: [
            [-0.25178,-0.79023,0.882], [-0.2418,-0.75533,0.772], [-0.22685,-0.70547,0.79], [-0.20192,-0.67057,0.78],
            [-0.16702,-0.64066,0.795], [-0.10719,-0.65561,0.761], [-0.05235,-0.67057,0.884], [0.00249,-0.6955,0.886],
            [0.05235,-0.70048,0.894], [0.10221,-0.70048,0.878], [0.15206,-0.68553,0.876], [0.20192,-0.69051,0.792],
            [0.24679,-0.69051,0.796], [0.27172,-0.7304,0.734], [0.28668,-0.77527,0.716], [0.28668,-0.82014,0.731],
            [0.2767,-0.85504,0.839], [-0.20192,-1.0096,0.957], [-0.17201,-1.04449,0.972], [-0.13212,-1.06444,0.973],
            [-0.09722,-1.07441,0.99], [-0.05235,-1.07939,0.979], [0.06731,-1.08937,0.998], [0.10221,-1.08937,1.014],
            [0.13711,-1.08937,1.012], [0.17201,-1.07939,0.986], [0.2069,-1.04948,0.978], [0.01745,-1.03452,1.062],
            [0.02244,-1.03452,1.078], [0.02742,-1.03452,1.044], [0.02742,-1.03452,0.995], [-0.02244,-0.9398,1.003],
            [0.00249,-0.94977,1.044], [0.03241,-0.95974,1.029], [0.05734,-0.95475,1.009], [0.08725,-0.94977,0.982],
            [-0.16702,-0.97968,0.968], [-0.13711,-1.00461,0.962], [-0.09722,-1.01957,0.986], [-0.06232,-1.00461,1.017],
            [-0.09722,-0.98965,0.997], [-0.12713,-0.97968,0.961], [0.08725,-1.01957,1.003], [0.11716,-1.03452,1.001],
            [0.15705,-1.02954,1.022], [0.18696,-1.00461,1.02], [0.15705,-0.99962,1.03], [0.12215,-1.00461,1.015],
            [-0.05734,-0.84008,0.932], [-0.02742,-0.89493,0.98], [0.02244,-0.92982,1.003], [0.03739,-0.93481,1.003],
            [0.05734,-0.93481,0.996], [0.10719,-0.90988,1.011], [0.14209,-0.86003,0.972], [0.10719,-0.86501,0.972],
            [0.07229,-0.87498,0.962], [0.04238,-0.87498,0.971], [0.01246,-0.86501,0.963], [-0.02244,-0.85504,0.976],
            [-0.05235,-0.84507,0.938], [-0.00748,-0.88495,0.986], [0.04238,-0.9049,0.99], [0.08725,-0.89493,0.979],
            [0.13212,-0.86501,0.97], [0.08725,-0.89493,0.957], [0.04238,-0.9049,0.973], [-0.00249,-0.88495,0.96]
        ]
    }
};

// ========== 머리 이식 시스템 ==========
let transplantBasePose = null;
let currentHeadPreset = null;

function ensureTransplantBase() {
    if (!transplantBasePose) {
        transplantBasePose = {
            body: [...poseData.pose_keypoints_2d],
            face: [...poseData.face_keypoints_2d],
        };
    }
}

function restoreTransplantBase() {
    if (transplantBasePose) {
        poseData.pose_keypoints_2d = [...transplantBasePose.body];
        poseData.face_keypoints_2d = [...transplantBasePose.face];
    }
}

function applyHeadTransplant(presetKey) {
    const preset = HEAD_PRESETS[presetKey];
    if (!preset) return;

    saveHistory();
    ensureTransplantBase();
    restoreTransplantBase();

    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 18 * 3) return;

    const neckX = kpts[1 * 3];
    const neckY = kpts[1 * 3 + 1];
    const noseX = kpts[0 * 3];
    const noseY = kpts[0 * 3 + 1];

    if (kpts[1 * 3 + 2] <= 0 || kpts[0 * 3 + 2] <= 0) {
        showStatus('Neck 또는 Nose가 없어 이식 불가');
        return;
    }

    const origScale = Math.sqrt((noseX - neckX) ** 2 + (noseY - neckY) ** 2);
    if (origScale < 1) {
        showStatus('Nose-Neck 거리가 너무 작음');
        return;
    }

    const headBodyIndices = [0, 14, 15, 16, 17];

    headBodyIndices.forEach(idx => {
        const presetPt = preset.body_head[idx];
        if (!presetPt) return;

        const [normX, normY, conf] = presetPt;
        kpts[idx * 3]     = neckX + normX * origScale;
        kpts[idx * 3 + 1] = neckY + normY * origScale;
        kpts[idx * 3 + 2] = conf;
    });

    if (preset.face_68 && preset.face_68.length === 68) {
        const faceKpts = poseData.face_keypoints_2d;

        while (faceKpts.length < 68 * 3) faceKpts.push(0, 0, 0);

        preset.face_68.forEach((pt, i) => {
            const [normX, normY, conf] = pt;
            faceKpts[i * 3]     = neckX + normX * origScale;
            faceKpts[i * 3 + 1] = neckY + normY * origScale;
            faceKpts[i * 3 + 2] = conf;
        });
    }

    currentHeadPreset = presetKey;
    updateHeadPresetUI();
    render();
    updateUI();
    showStatus(`머리 이식: ${preset.label}`);
}

function updateHeadPresetUI() {
    document.querySelectorAll('.head-preset-btn').forEach(btn => {
        btn.classList.toggle('on', btn.dataset.preset === currentHeadPreset);
    });
}

function resetHeadTransplant() {
    if (transplantBasePose) {
        poseData.pose_keypoints_2d = [...transplantBasePose.body];
        poseData.face_keypoints_2d = [...transplantBasePose.face];
        transplantBasePose = null;
    }

    currentHeadPreset = null;
    updateHeadPresetUI();
    render();
    updateUI();
    showStatus('머리 이식 초기화');
}


// ========== 전체 변형 ==========
function scalePose(factor, pivot = 'center') {
    saveHistory();

    let pivotX, pivotY;
    const kpts = poseData.pose_keypoints_2d;

    if (pivot === 'neck' && kpts.length > JOINT.NECK * 3 + 2 && kpts[JOINT.NECK * 3 + 2] > 0) {
        pivotX = kpts[JOINT.NECK * 3];
        pivotY = kpts[JOINT.NECK * 3 + 1];
    } else {
        pivotX = canvasWidth / 2;
        pivotY = canvasHeight / 2;
    }

    for (let i = 0; i < kpts.length; i += 3) {
        if (kpts[i + 2] <= 0) continue;
        kpts[i] = pivotX + (kpts[i] - pivotX) * factor;
        kpts[i + 1] = pivotY + (kpts[i + 1] - pivotY) * factor;
    }

    [poseData.hand_left_keypoints_2d, poseData.hand_right_keypoints_2d].forEach(hkpts => {
        if (!hkpts) return;
        for (let i = 0; i < hkpts.length; i += 3) {
            if (hkpts[i + 2] <= 0) continue;
            hkpts[i] = pivotX + (hkpts[i] - pivotX) * factor;
            hkpts[i + 1] = pivotY + (hkpts[i + 1] - pivotY) * factor;
        }
    });

    const fkpts = poseData.face_keypoints_2d;
    if (fkpts) {
        for (let i = 0; i < fkpts.length; i += 3) {
            if (fkpts[i + 2] <= 0) continue;
            fkpts[i] = pivotX + (fkpts[i] - pivotX) * factor;
            fkpts[i + 1] = pivotY + (fkpts[i + 1] - pivotY) * factor;
        }
    }

    resetAllBases();
    render();
    showStatus(`스케일 ${Math.round(factor * 100)}% (${pivot})`);
}


// ========== 렌더링 ==========
function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const lineThickness = parseInt(document.getElementById('lineThickness').value);
    const pointRadius = parseInt(document.getElementById('pointRadius').value);

    // 배경
    if (showBackground && backgroundImage) {
        const opacity = parseInt(document.getElementById('bgOpacity').value) / 100;
        ctx.globalAlpha = opacity;
        ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);
        ctx.globalAlpha = 1.0;
    }

    // 스켈레톤
    if (showSkeleton) {
        drawBody(lineThickness, pointRadius);
        drawHand(poseData.hand_left_keypoints_2d, Math.max(1, lineThickness - 2), pointRadius);
        drawHand(poseData.hand_right_keypoints_2d, Math.max(1, lineThickness - 2), pointRadius);
        drawFace(Math.max(1, pointRadius - 1));
    }

    // 선택 하이라이트는 항상 표시
    drawSelectionHighlight(pointRadius);
}

// HSL(h, 100%, 50%) → RGB → R/B swap to match renderer BGR output
function hslToSwappedRgb(hDeg) {
    const x = 1 - Math.abs((hDeg / 60) % 2 - 1);
    let r, g, b;
    if (hDeg < 60)       { r = 1; g = x; b = 0; }
    else if (hDeg < 120) { r = x; g = 1; b = 0; }
    else if (hDeg < 180) { r = 0; g = 1; b = x; }
    else if (hDeg < 240) { r = 0; g = x; b = 1; }
    else if (hDeg < 300) { r = x; g = 0; b = 1; }
    else                 { r = 1; g = 0; b = x; }
    return `rgb(${Math.round(b * 255)},${Math.round(g * 255)},${Math.round(r * 255)})`;
}

// drawBody - util.py draw_bodypose_with_feet()와 동일한 렌더링 로직
//
// [렌더러 대응]
// - 선 그리기: util.py는 cv2.fillConvexPoly(ellipse2Poly)로 두꺼운 타원형 선을 그림
//   에디터는 canvas lineTo + round lineCap으로 유사하게 표현
// - 선 색상: LIMB_SEQ 인덱스(i)에 따라 BODY_COLORS[i] 사용
//   발 관절이 포함된 연결은 ankle 색상으로 통일 (util.py와 동일)
//   - LEFT_FOOT(LAnkle=13, LBigToe=18, LSmToe=19, LHeel=20) → BODY_COLORS[13]
//   - RIGHT_FOOT(RAnkle=10, RBigToe=21, RSmToe=22, RHeel=23) → BODY_COLORS[10]
// - 선 두께: [0~16] body → lineThickness, [17~24] feet → lineThickness-2
//   util.py: body → stickwidth(4+mod), feet → feet_stickwidth(2+hand_mod)
// - opacity: util.py는 선 그린 후 canvas *= pose_opacity, 그 위에 점을 그림
//   에디터: ctx.globalAlpha = poseOpacity로 선, 점은 globalAlpha=1.0 (동일 효과)
// - 점 크기: [0~17] body → pointRadius, [18~23] feet → pointRadius-1
//   util.py: body → dot_radius(4+mod), feet(>=18) → feet_dot_radius(4+hand_dot_mod)
function drawBody(lineThickness, pointRadius) {
    const kpts = poseData.pose_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const poseOpacity = parseInt(document.getElementById('poseOpacity').value) / 100;

    // util.py의 LEFT_FOOT_JOINTS, RIGHT_FOOT_JOINTS와 동일
    const LEFT_FOOT = new Set([13, 18, 19, 20]);   // LAnkle, LBigToe, LSmToe, LHeel
    const RIGHT_FOOT = new Set([10, 21, 22, 23]);  // RAnkle, RBigToe, RSmToe, RHeel

    // 선 그리기 - util.py: canvas = (canvas * pose_opacity) 후 점 그리기와 동일 효과
    ctx.globalAlpha = poseOpacity;

    for (let i = 0; i < LIMB_SEQ.length; i++) {
        const [a, b] = LIMB_SEQ[i];
        const idxA = a - 1, idxB = b - 1;
        if (idxA * 3 + 2 >= kpts.length || idxB * 3 + 2 >= kpts.length) continue;
        if (kpts[idxA * 3 + 2] <= 0.3 || kpts[idxB * 3 + 2] <= 0.3) continue;

        const x1 = kpts[idxA * 3], y1 = kpts[idxA * 3 + 1];
        const x2 = kpts[idxB * 3], y2 = kpts[idxB * 3 + 1];

        // util.py와 동일: 발 관절 포함 시 ankle 색상, 아니면 limb 인덱스 색상
        let color = BODY_COLORS[i] || BODY_COLORS[0];
        if (LEFT_FOOT.has(idxA) || LEFT_FOOT.has(idxB)) color = BODY_COLORS[13];
        else if (RIGHT_FOOT.has(idxA) || RIGHT_FOOT.has(idxB)) color = BODY_COLORS[10];

        ctx.strokeStyle = `rgb(${color[0]},${color[1]},${color[2]})`;
        // util.py: i>=17 → feet_stickwidth(가는 선), 그 외 → stickwidth
        ctx.lineWidth = i >= 17 ? Math.max(1, lineThickness - 2) : lineThickness;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    // 점 그리기 - util.py: 선에 opacity 적용 후 점은 풀 밝기로 그림
    ctx.globalAlpha = 1.0;

    const bodyPts = Math.min(24, Math.floor(kpts.length / 3));
    for (let i = 0; i < bodyPts; i++) {
        if (kpts[i * 3 + 2] <= 0.3) continue;

        // util.py와 동일: 발 관절은 ankle 색상, 아니면 키포인트 인덱스 색상
        let color = BODY_COLORS[i] || BODY_COLORS[0];
        if (LEFT_FOOT.has(i)) color = BODY_COLORS[13];
        else if (RIGHT_FOOT.has(i)) color = BODY_COLORS[10];

        ctx.fillStyle = `rgb(${color[0]},${color[1]},${color[2]})`;
        ctx.beginPath();
        // util.py: body dot_radius=4, feet_dot_radius=4 (동일)
        ctx.arc(kpts[i * 3], kpts[i * 3 + 1], pointRadius, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.globalAlpha = 1.0;
}

// drawHand - util.py draw_handpose()와 동일한 렌더링 로직
//
// [렌더러 대응]
// - 선 색상: util.py HSV(ie/20, 1.0, 1.0) = 에디터 HSL(ie/20*360, 100%, 50%) → 동일
//   HSV(h, s=1, v=1)은 수학적으로 HSL(h, s=1, l=0.5)과 완전히 동일
// - 선 두께: util.py line_thickness = max(1, 2+mod), 에디터: lineThickness-2
// - 점 색상: util.py BGR(0,0,255) = RGB(255,0,0) = 빨강 → 에디터: rgb(255,0,0) 동일
// - 점 크기: util.py dot_radius = max(1, 4+mod), 에디터: pointRadius
function drawHand(kpts, lineThickness, pointRadius) {
    if (!kpts || kpts.length < 3) return;

    for (let ie = 0; ie < HAND_EDGES.length; ie++) {
        const [a, b] = HAND_EDGES[ie];
        if (a * 3 + 2 >= kpts.length || b * 3 + 2 >= kpts.length) continue;
        if (kpts[a * 3 + 2] <= 0.1 || kpts[b * 3 + 2] <= 0.1) continue;

        const x1 = kpts[a * 3], y1 = kpts[a * 3 + 1];
        const x2 = kpts[b * 3], y2 = kpts[b * 3 + 1];

        // util.py: HSV→RGB→BGR for OpenCV, R/B swapped to match renderer output
        ctx.strokeStyle = hslToSwappedRgb((ie / HAND_EDGES.length) * 360);
        ctx.lineWidth = lineThickness;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    const handPts = Math.min(21, Math.floor(kpts.length / 3));
    for (let i = 0; i < handPts; i++) {
        if (kpts[i * 3 + 2] <= 0.1) continue;
        // util.py: BGR(0,0,255) → ComfyUI no conversion → displayed as rgb(0,0,255)
        ctx.fillStyle = 'rgb(0, 0, 255)';
        ctx.beginPath();
        ctx.arc(kpts[i * 3], kpts[i * 3 + 1], pointRadius, 0, Math.PI * 2);
        ctx.fill();
    }
}

// drawFace - util.py draw_facepose()와 동일한 렌더링 로직
//
// [렌더러 대응]
// - 점 색상: util.py (255,255,255) = 흰색 → 에디터: rgb(255,255,255) 동일
//   ※ util.py에서 (255,255,255)는 BGR이든 RGB이든 동일하게 흰색
// - 점 크기: util.py dot_radius = max(1, 3+mod), 에디터: pointRadius-1 (render()에서 전달)
// - 얼굴은 선(edge) 없이 점만 그림 (util.py와 동일)
function drawFace(pointRadius) {
    const kpts = poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const facePts = Math.min(68, Math.floor(kpts.length / 3));
    for (let i = 0; i < facePts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        // util.py: cv2.circle(..., (255, 255, 255), ...) → 흰색
        ctx.fillStyle = 'rgb(255, 255, 255)';
        ctx.beginPath();
        ctx.arc(kpts[i * 3], kpts[i * 3 + 1], pointRadius, 0, Math.PI * 2);
        ctx.fill();
    }
}

function drawSelectionHighlight(pointRadius) {
    selectedPoints.forEach(p => {
        const arr = getArrayByType(p.type);
        if (!arr || arr[p.index * 3 + 2] <= 0) return;
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(arr[p.index * 3], arr[p.index * 3 + 1], pointRadius + 4, 0, Math.PI * 2);
        ctx.stroke();
    });
}

// ========== 시작 ==========
init();
