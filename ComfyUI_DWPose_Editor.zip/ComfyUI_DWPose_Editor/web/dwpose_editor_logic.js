// ========== ComfyUI 통신 ==========
let nodeId = null;

// URL에서 nodeId 가져오기
const urlParams = new URLSearchParams(window.location.search);
nodeId = urlParams.get('nodeId');

// 초기 JSON 데이터 받기
window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'loadPose') {
        try {
            loadJSON(event.data.json);
        } catch (e) {
            console.error('Failed to load pose:', e);
        }
    }
    else if (event.data && event.data.type === 'loadBackground') {
        try {
            loadBackgroundFromUrl(event.data.imageData);
        } catch (e) {
            console.error('Failed to load background:', e);
        }
    }
});

// URL에서 배경 이미지 로드
function loadBackgroundFromUrl(url) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
        backgroundImage = img;
        render();
        showStatus('배경 이미지 자동 로드됨');
    };
    img.onerror = () => {};
    img.src = url;
}

// Node로 JSON 전송
function sendToNode() {
    const output = getJSONOutput();

    if (window.opener) {
        window.opener.postMessage({
            type: 'poseData',
            nodeId: nodeId,
            json: JSON.stringify(output)
        }, '*');
        showStatus('✓ Sent to Node!');

        // 1초 후 창 닫기
        setTimeout(() => window.close(), 1000);
    } else {
        // 팝업이 아닌 경우 클립보드에 복사
        navigator.clipboard.writeText(JSON.stringify(output, null, 2)).then(() => {
            showStatus('✓ Copied to clipboard!');
        });
    }
}

function getJSONOutput() {
    return {
        people: [{
            pose_keypoints_2d: poseData.pose_keypoints_2d,
            hand_left_keypoints_2d: poseData.hand_left_keypoints_2d,
            hand_right_keypoints_2d: poseData.hand_right_keypoints_2d,
            face_keypoints_2d: poseData.face_keypoints_2d
        }],
        canvas_width: canvasWidth,
        canvas_height: canvasHeight
    };
}

// ==========================================================================
// 상수 - dwpose/util.py의 draw_bodypose_with_feet, draw_handpose, draw_facepose와 동일
//
// [렌더러 대응 관계]
// - BODY_COLORS  → util.py draw_bodypose_with_feet()의 colors 배열 (24색, RGB)
// - LIMB_SEQ     → util.py draw_bodypose_with_feet()의 limbSeq (25개 연결)
//                   ※ draw_bodypose_without_feet는 17개만 그림 (show_feet=False일 때)
//                   ※ 에디터는 항상 with_feet 기준으로 렌더링 (feet 키포인트 없으면 자동 스킵)
// - HAND_EDGES   → util.py draw_handpose()의 edges (20개 연결)
// - 손 선 색상   → util.py: HSV→RGB→BGR, 에디터: HSL→RGB→R/B swap (렌더러 BGR 출력 매칭)
// - 손 점 색상   → util.py: BGR(0,0,255), 에디터: rgb(0,0,255) (렌더러 BGR 출력 매칭)
// - 얼굴 점 색상 → util.py: BGR(255,255,255)=흰색 = 에디터: rgb(255,255,255) (동일)
// ==========================================================================

// Body 키포인트 색상 (24색) - util.py draw_bodypose_with_feet()의 colors와 동일
// 인덱스 0~17: 기본 body, 18~23: feet (발 관절은 ankle 색상으로 통일됨)
const BODY_COLORS = [
    [255, 0, 0], [255, 85, 0], [255, 170, 0], [255, 255, 0], [170, 255, 0],
    [85, 255, 0], [0, 255, 0], [0, 255, 85], [0, 255, 170], [0, 255, 255],
    [0, 170, 255], [0, 85, 255], [0, 0, 255], [85, 0, 255], [170, 0, 255],
    [255, 0, 255], [255, 0, 170], [255, 0, 85], [85, 0, 255], [85, 0, 255],
    [85, 0, 255], [0, 170, 255], [0, 170, 255], [0, 170, 255]
];

// Body 뼈대 연결 (1-indexed, 25개) - util.py draw_bodypose_with_feet()의 limbSeq과 동일
// [0~16] 17개: 기본 body 연결 (목-어깨, 팔, 다리, 머리 등)
// [17~24] 8개: feet 연결 (발목-발가락, 발목-발뒤꿈치 등)
const LIMB_SEQ = [
    [2, 3], [2, 6], [3, 4], [4, 5], [6, 7], [7, 8], [2, 9], [9, 10],
    [10, 11], [2, 12], [12, 13], [13, 14], [2, 1], [1, 15], [15, 17],
    [1, 16], [16, 18], [11, 24], [14, 21], [19, 21], [19, 20], [20, 21],
    [22, 24], [22, 23], [23, 24]
];

// Hand 뼈대 연결 (0-indexed, 20개) - util.py draw_handpose()의 edges와 동일
// 5개 손가락 × 4개 관절 연결
const HAND_EDGES = [
    [0, 1], [1, 2], [2, 3], [3, 4],
    [0, 5], [5, 6], [6, 7], [7, 8],
    [0, 9], [9, 10], [10, 11], [11, 12],
    [0, 13], [13, 14], [14, 15], [15, 16],
    [0, 17], [17, 18], [18, 19], [19, 20]
];

const BODY_NAMES = [
    '코', '목', '오른어깨', '오른팔꿈치', '오른손목', '왼어깨', '왼팔꿈치', '왼손목',
    '오른엉덩', '오른무릎', '오른발목', '왼엉덩', '왼무릎', '왼발목',
    '오른눈', '왼눈', '오른귀', '왼귀',
    '왼엄지발', '왼새끼발', '왼발뒤꿈치', '오른엄지발', '오른새끼발', '오른발뒤꿈치'
];

const HAND_NAMES = [
    '손목',
    '엄지CMC', '엄지MCP', '엄지IP', '엄지끝',
    '검지MCP', '검지PIP', '검지DIP', '검지끝',
    '중지MCP', '중지PIP', '중지DIP', '중지끝',
    '약지MCP', '약지PIP', '약지DIP', '약지끝',
    '소지MCP', '소지PIP', '소지DIP', '소지끝'
];

const FACE_NAMES = [
    // 턱라인 0-16
    '우관자놀이', '우턱위1', '우턱위2', '우턱위3',
    '우턱1', '우턱2', '우턱3',
    '턱중앙우', '턱끝', '턱중앙좌',
    '좌턱1', '좌턱2', '좌턱3',
    '좌턱위1', '좌턱위2', '좌턱위3', '좌관자놀이',
    // 오른눈썹 17-21
    '우눈썹안쪽', '우눈썹안중', '우눈썹중간', '우눈썹바중', '우눈썹바깥',
    // 왼눈썹 22-26
    '좌눈썹안쪽', '좌눈썹안중', '좌눈썹중간', '좌눈썹바중', '좌눈썹바깥',
    // 코 27-35
    '콧대위', '콧대중상', '콧대중하', '콧대아래',
    '우콧볼위', '우콧볼', '코끝', '좌콧볼', '좌콧볼위',
    // 오른눈 36-41
    '우눈안끝', '우눈위안', '우눈위밖', '우눈밖끝', '우눈아래밖', '우눈아래안',
    // 왼눈 42-47
    '좌눈안끝', '좌눈위안', '좌눈위밖', '좌눈밖끝', '좌눈아래밖', '좌눈아래안',
    // 입 바깥 48-59
    '입우끝', '윗입술우', '윗입술우중', '윗입술중앙', '윗입술좌중', '윗입술좌',
    '입좌끝', '아랫입술좌', '아랫입술좌중', '아랫입술중앙', '아랫입술우중', '아랫입술우',
    // 입 안쪽 60-67
    '윗입안우', '윗입안중', '윗입안좌',
    '입안좌끝',
    '아랫입안좌', '아랫입안중', '아랫입안우',
    '입안우끝'
];

const PART_COUNTS = { body: 24, face: 68, leftHand: 21, rightHand: 21 };

// ========== FK 관절 체인 시스템 ==========
const JOINT = {
    NOSE: 0, NECK: 1,
    R_SHOULDER: 2, R_ELBOW: 3, R_WRIST: 4,
    L_SHOULDER: 5, L_ELBOW: 6, L_WRIST: 7,
    R_HIP: 8, R_KNEE: 9, R_ANKLE: 10,
    L_HIP: 11, L_KNEE: 12, L_ANKLE: 13,
    R_EYE: 14, L_EYE: 15, R_EAR: 16, L_EAR: 17,
    L_BIGTOE: 18, L_SMALLTOE: 19, L_HEEL: 20,
    R_BIGTOE: 21, R_SMALLTOE: 22, R_HEEL: 23
};

const BONE_HIERARCHY = {
    [JOINT.NECK]: {
        children: [JOINT.NOSE, JOINT.R_SHOULDER, JOINT.L_SHOULDER, JOINT.R_HIP, JOINT.L_HIP],
        includesFace: false
    },
    [JOINT.NOSE]: {
        children: [JOINT.R_EYE, JOINT.L_EYE],
        includesFace: true
    },
    [JOINT.R_EYE]: { children: [JOINT.R_EAR] },
    [JOINT.L_EYE]: { children: [JOINT.L_EAR] },
    [JOINT.R_SHOULDER]: { children: [JOINT.R_ELBOW] },
    [JOINT.R_ELBOW]: { children: [JOINT.R_WRIST] },
    [JOINT.R_WRIST]: { children: [], includesHand: 'right' },
    [JOINT.L_SHOULDER]: { children: [JOINT.L_ELBOW] },
    [JOINT.L_ELBOW]: { children: [JOINT.L_WRIST] },
    [JOINT.L_WRIST]: { children: [], includesHand: 'left' },
    [JOINT.R_HIP]: { children: [JOINT.R_KNEE] },
    [JOINT.R_KNEE]: { children: [JOINT.R_ANKLE] },
    [JOINT.R_ANKLE]: { children: [JOINT.R_BIGTOE, JOINT.R_SMALLTOE, JOINT.R_HEEL] },
    [JOINT.L_HIP]: { children: [JOINT.L_KNEE] },
    [JOINT.L_KNEE]: { children: [JOINT.L_ANKLE] },
    [JOINT.L_ANKLE]: { children: [JOINT.L_BIGTOE, JOINT.L_SMALLTOE, JOINT.L_HEEL] }
};

function rotateJoint(pivotJointId, angleDeg) {
    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 24 * 3) return;

    const pivotX = kpts[pivotJointId * 3];
    const pivotY = kpts[pivotJointId * 3 + 1];

    if (kpts[pivotJointId * 3 + 2] <= 0) return;

    const angleRad = angleDeg * Math.PI / 180;
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);

    const toRotate = collectChildren(pivotJointId);

    toRotate.bodyJoints.forEach(jointId => {
        if (jointId * 3 + 2 >= kpts.length) return;
        if (kpts[jointId * 3 + 2] <= 0) return;
        const x = kpts[jointId * 3] - pivotX;
        const y = kpts[jointId * 3 + 1] - pivotY;
        kpts[jointId * 3] = pivotX + x * cos - y * sin;
        kpts[jointId * 3 + 1] = pivotY + x * sin + y * cos;
    });

    if (toRotate.includesRightHand) {
        rotateHandAroundPivot('right', pivotX, pivotY, cos, sin);
    }
    if (toRotate.includesLeftHand) {
        rotateHandAroundPivot('left', pivotX, pivotY, cos, sin);
    }
    if (toRotate.includesFace) {
        rotateFaceAroundPivot(pivotX, pivotY, cos, sin);
    }
}

function collectChildren(jointId) {
    const result = {
        bodyJoints: [],
        includesRightHand: false,
        includesLeftHand: false,
        includesFace: false
    };

    const visited = new Set();
    const queue = [jointId];

    while (queue.length > 0) {
        const current = queue.shift();
        if (visited.has(current)) continue;
        visited.add(current);

        const node = BONE_HIERARCHY[current];
        if (!node) continue;

        node.children.forEach(child => {
            result.bodyJoints.push(child);
            queue.push(child);
        });

        if (node.includesHand === 'right') result.includesRightHand = true;
        if (node.includesHand === 'left') result.includesLeftHand = true;
        if (node.includesFace) result.includesFace = true;
    }

    return result;
}

function rotateHandAroundPivot(side, pivotX, pivotY, cos, sin) {
    const kpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const numPts = Math.floor(kpts.length / 3);
    for (let i = 0; i < numPts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        const x = kpts[i * 3] - pivotX;
        const y = kpts[i * 3 + 1] - pivotY;
        kpts[i * 3] = pivotX + x * cos - y * sin;
        kpts[i * 3 + 1] = pivotY + x * sin + y * cos;
    }
}

function rotateFaceAroundPivot(pivotX, pivotY, cos, sin) {
    const kpts = poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const numPts = Math.floor(kpts.length / 3);
    for (let i = 0; i < numPts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        const x = kpts[i * 3] - pivotX;
        const y = kpts[i * 3 + 1] - pivotY;
        kpts[i * 3] = pivotX + x * cos - y * sin;
        kpts[i * 3 + 1] = pivotY + x * sin + y * cos;
    }

    baseFaceData = null;
}

function getJointAngle(parentId, childId) {
    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 24 * 3) return 0;
    const px = kpts[parentId * 3];
    const py = kpts[parentId * 3 + 1];
    const cx = kpts[childId * 3];
    const cy = kpts[childId * 3 + 1];
    return Math.atan2(cy - py, cx - px) * 180 / Math.PI;
}

// ========== 상태 ==========
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

let canvasWidth = 512, canvasHeight = 768;
let zoom = 1;
let backgroundImage = null;

let showBackground = true;
let showSkeleton = true;

let poseData = {
    pose_keypoints_2d: [],
    hand_left_keypoints_2d: [],
    hand_right_keypoints_2d: [],
    face_keypoints_2d: []
};

let selectedPoints = [];
let isDragging = false;
let dragStartX = 0, dragStartY = 0;
let dragPointsStart = [];

let isBoxSelecting = false;
let boxStartX = 0, boxStartY = 0, boxEndX = 0, boxEndY = 0;

let isPanning = false;
let panStartX = 0, panStartY = 0;
let panScrollStartX = 0, panScrollStartY = 0;
let spacePressed = false;

let history = [];
let historyIndex = -1;
const MAX_HISTORY = 50;

// ========== 헬퍼 함수 ==========
let handPresetBase = { left: null, right: null };

function resetAllBases() {
    baseFaceData = null;
    fkBasePose = null;
    fake3dBasePose = null;
    handPresetBase = { left: null, right: null };
}

function resetAllSliders() {
    ['fkHead', 'fkRShoulder', 'fkRElbow', 'fkRWrist',
     'fkLShoulder', 'fkLElbow', 'fkLWrist',
     'fkRHip', 'fkRKnee', 'fkLHip', 'fkLKnee'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.value = 0;
            const valEl = document.getElementById(id + 'Value');
            if (valEl) valEl.textContent = '0°';
        }
    });

    ['gazeX', 'gazeY', 'mouthOpen', 'eyeClose'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = 0;
    });
    const exprVals = {
        'gazeXValue': '0', 'gazeYValue': '0',
        'mouthOpenValue': '0', 'eyeCloseValue': '0'
    };
    Object.entries(exprVals).forEach(([id, val]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    });

    const fake3dParts = ['Head', 'Shoulder', 'Waist', 'Pelvis', 'Leg'];
    fake3dParts.forEach(part => {
        ['Turn', 'Lean'].forEach(axis => {
            const id = `fake3d${part}${axis}`;
            const el = document.getElementById(id);
            if (el) el.value = 0;
            const valEl = document.getElementById(id + 'Value');
            if (valEl) valEl.textContent = '0';
        });
    });
}

// ========== 초기화 ==========
function init() {
    createToggleButtons();
    setupEventListeners();

    // 초기 줌 100%, 스크롤로 탐색
    zoom = 1;
    applyZoom();
    document.getElementById('statusZoom').textContent = '100%';
    setTimeout(() => centerCanvas(), 100);

    // 부모 창에 준비 완료 알림
    if (window.opener) {
        window.opener.postMessage({ type: 'editorReady', nodeId: nodeId }, '*');
    }
}

const BODY_GROUPS = [
    { name: '머리', indices: [0, 1, 14, 15, 16, 17] },
    { name: '오른팔', indices: [2, 3, 4] },
    { name: '왼팔', indices: [5, 6, 7] },
    { name: '오른다리', indices: [8, 9, 10] },
    { name: '왼다리', indices: [11, 12, 13] },
    { name: '오른발', indices: [21, 22, 23] },
    { name: '왼발', indices: [18, 19, 20] }
];

const HAND_GROUPS = [
    { name: '손목', indices: [0] },
    { name: '엄지', indices: [1, 2, 3, 4] },
    { name: '검지', indices: [5, 6, 7, 8] },
    { name: '중지', indices: [9, 10, 11, 12] },
    { name: '약지', indices: [13, 14, 15, 16] },
    { name: '소지', indices: [17, 18, 19, 20] }
];

const FACE_GROUPS = [
    { name: '턱라인', indices: Array.from({length: 17}, (_, i) => i) },
    { name: '왼눈썹', indices: [17, 18, 19, 20, 21] },
    { name: '오른눈썹', indices: [22, 23, 24, 25, 26] },
    { name: '코', indices: [27, 28, 29, 30, 31, 32, 33, 34, 35] },
    { name: '왼눈', indices: [36, 37, 38, 39, 40, 41] },
    { name: '오른눈', indices: [42, 43, 44, 45, 46, 47] },
    { name: '입 바깥', indices: [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59] },
    { name: '입 안쪽', indices: [60, 61, 62, 63, 64, 65, 66, 67] }
];

function createGroupedToggles(container, type, groups, nameArray) {
    groups.forEach(group => {
        const groupDiv = document.createElement('div');
        groupDiv.className = 'toggle-group';
        groupDiv.dataset.type = type;

        const header = document.createElement('div');
        header.className = 'toggle-group-header';
        header.innerHTML = `
            <span class="toggle-group-arrow">▶</span>
            <span class="toggle-group-name">${group.name}</span>
            <span class="toggle-group-count" data-group-type="${type}" data-group-name="${group.name}">${group.indices.length}/${group.indices.length}</span>
            <button class="accordion-btn" title="모두 켜기" onclick="event.stopPropagation(); toggleGroup('${type}', [${group.indices}], true)">ON</button>
            <button class="accordion-btn" title="모두 끄기" onclick="event.stopPropagation(); toggleGroup('${type}', [${group.indices}], false)">OFF</button>
        `;
        header.onclick = (e) => {
            if (e.target.tagName === 'BUTTON') return;
            groupDiv.classList.toggle('open');
        };
        groupDiv.appendChild(header);

        const content = document.createElement('div');
        content.className = 'toggle-group-content';
        const grid = document.createElement('div');
        grid.className = 'toggle-grid';

        group.indices.forEach(i => {
            const btn = document.createElement('button');
            btn.className = 'toggle-btn on';
            btn.textContent = nameArray[i] || i;
            btn.title = nameArray[i] || `${type} ${i}`;
            btn.dataset.type = type;
            btn.dataset.index = i;
            btn.onclick = () => togglePoint(type, i);
            grid.appendChild(btn);
        });

        content.appendChild(grid);
        groupDiv.appendChild(content);
        container.appendChild(groupDiv);
    });
}

function toggleGroup(type, indices, turnOn) {
    saveHistory();
    const arr = getArrayByType(type);
    while (arr.length < Math.max(...indices) * 3 + 3) arr.push(0, 0, 0);

    indices.forEach(i => {
        if (turnOn) {
            if (arr[i * 3] === 0 && arr[i * 3 + 1] === 0) {
                arr[i * 3] = canvasWidth / 2 + (Math.random() - 0.5) * 100;
                arr[i * 3 + 1] = canvasHeight / 2 + (Math.random() - 0.5) * 100;
            }
            arr[i * 3 + 2] = 1.0;
        } else {
            arr[i * 3 + 2] = 0;
        }
    });

    updateUI();
    render();
    showStatus(turnOn ? `${type} 그룹 켜기` : `${type} 그룹 끄기`);
}

function createToggleButtons() {
    const bodyGrid = document.getElementById('toggles-body');
    createGroupedToggles(bodyGrid, 'body', BODY_GROUPS, BODY_NAMES);

    const faceGrid = document.getElementById('toggles-face');
    createGroupedToggles(faceGrid, 'face', FACE_GROUPS, FACE_NAMES);

    ['leftHand', 'rightHand'].forEach(hand => {
        const grid = document.getElementById(`toggles-${hand}`);
        createGroupedToggles(grid, hand, HAND_GROUPS, HAND_NAMES);
    });
}

function setupEventListeners() {
    const wrapper = document.getElementById('canvasWrapper');
    wrapper.addEventListener('mousedown', onMouseDown);
    wrapper.addEventListener('mousemove', onMouseMove);
    wrapper.addEventListener('mouseup', onMouseUp);
    wrapper.addEventListener('mouseleave', onMouseUp);
    wrapper.addEventListener('contextmenu', onRightClick);
    wrapper.addEventListener('wheel', onWheel, { passive: false });

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
}

// ========== 유틸 ==========
function getArrayByType(type) {
    switch(type) {
        case 'body': return poseData.pose_keypoints_2d;
        case 'leftHand': return poseData.hand_left_keypoints_2d;
        case 'rightHand': return poseData.hand_right_keypoints_2d;
        case 'face': return poseData.face_keypoints_2d;
    }
}

function getNameByTypeAndIndex(type, index) {
    if (type === 'body') return BODY_NAMES[index] || `Body ${index}`;
    if (type === 'leftHand') return `왼${HAND_NAMES[index]}` || `왼손 ${index}`;
    if (type === 'rightHand') return `오른${HAND_NAMES[index]}` || `오른손 ${index}`;
    if (type === 'face') return FACE_NAMES[index] || `얼굴 ${index}`;
}

function showStatus(msg) {
    const el = document.getElementById('statusMsg');
    el.textContent = msg;
    setTimeout(() => el.textContent = '', 2000);
}

// ========== History ==========
function saveHistory() {
    const state = JSON.stringify(poseData);
    history = history.slice(0, historyIndex + 1);
    if (history.length > 0 && history[history.length - 1] === state) return;
    history.push(state);
    historyIndex = history.length - 1;
    if (history.length > MAX_HISTORY) { history.shift(); historyIndex--; }
}

function undo() {
    if (historyIndex > 0) {
        historyIndex--;
        poseData = JSON.parse(history[historyIndex]);
        resetAllBases();
        resetAllSliders();
        selectedPoints = [];
        updateUI();
        render();
        showStatus('실행취소');
    }
}

function redo() {
    if (historyIndex < history.length - 1) {
        historyIndex++;
        poseData = JSON.parse(history[historyIndex]);
        resetAllBases();
        resetAllSliders();
        selectedPoints = [];
        updateUI();
        render();
        showStatus('다시실행');
    }
}

// ========== UI 업데이트 ==========
function updateUI() {
    document.querySelectorAll('.toggle-btn').forEach(btn => {
        const type = btn.dataset.type;
        const idx = parseInt(btn.dataset.index);
        const arr = getArrayByType(type);
        const isOn = arr.length > idx * 3 + 2 && arr[idx * 3 + 2] > 0;
        btn.classList.toggle('on', isOn);
    });

    Object.keys(PART_COUNTS).forEach(part => {
        const arr = getArrayByType(part);
        let count = 0;
        for (let i = 0; i < PART_COUNTS[part] && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] > 0) count++;
        }
        document.getElementById(`count-${part}`).textContent = `${count}/${PART_COUNTS[part]}`;
    });

    let total = 0;
    Object.keys(PART_COUNTS).forEach(part => {
        const arr = getArrayByType(part);
        for (let i = 0; i < PART_COUNTS[part] && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] > 0) total++;
        }
    });
    document.getElementById('statusPoints').textContent = `${total}/134 points`;
    document.getElementById('statusSelected').textContent = `${selectedPoints.length} selected`;
    document.getElementById('statusSize').textContent = `${canvasWidth} × ${canvasHeight}`;

    const info = document.getElementById('selectionInfo');
    if (selectedPoints.length === 0) info.textContent = '선택: 없음';
    else if (selectedPoints.length === 1) info.textContent = `선택: ${selectedPoints[0].name}`;
    else info.textContent = `선택: ${selectedPoints.length}개`;

    updateCoordInputs();
}

function updateCoordInputs() {
    const coordX = document.getElementById('coordX');
    const coordY = document.getElementById('coordY');
    if (selectedPoints.length === 1) {
        const p = selectedPoints[0];
        const arr = getArrayByType(p.type);
        coordX.value = Math.round(arr[p.index * 3]);
        coordY.value = Math.round(arr[p.index * 3 + 1]);
    } else {
        coordX.value = '';
        coordY.value = '';
    }
}

function updateDisplay() {
    document.getElementById('lineThicknessValue').textContent = document.getElementById('lineThickness').value;
    document.getElementById('pointRadiusValue').textContent = document.getElementById('pointRadius').value;
    render();
}

// ========== 배경/스켈레톤 토글 ==========
function toggleBackground() {
    showBackground = !showBackground;
    document.getElementById('toggleBg').textContent = showBackground ? '배경 ON' : '배경 OFF';
    document.getElementById('toggleBg').classList.toggle('on', showBackground);
    render();
}

function toggleSkeleton() {
    showSkeleton = !showSkeleton;
    document.getElementById('toggleSkeleton').textContent = showSkeleton ? '스켈레톤 ON' : '스켈레톤 OFF';
    document.getElementById('toggleSkeleton').classList.toggle('on', showSkeleton);
    render();
}

function updateBgOpacity() {
    document.getElementById('bgOpacityValue').textContent = document.getElementById('bgOpacity').value + '%';
    render();
}

function updatePoseOpacity() {
    const val = parseInt(document.getElementById('poseOpacity').value);
    document.getElementById('poseOpacityValue').textContent = val + '%';
    render();
}

// ========== 토글 ==========
function toggleAccordion(header) {
    header.parentElement.classList.toggle('open');
}

function togglePoint(type, index) {
    saveHistory();
    const arr = getArrayByType(type);
    while (arr.length < (index + 1) * 3) arr.push(0, 0, 0);

    if (arr[index * 3 + 2] > 0) {
        arr[index * 3 + 2] = 0;
    } else {
        if (arr[index * 3] === 0 && arr[index * 3 + 1] === 0) {
            arr[index * 3] = canvasWidth / 2 + (Math.random() - 0.5) * 100;
            arr[index * 3 + 1] = canvasHeight / 2 + (Math.random() - 0.5) * 100;
        }
        arr[index * 3 + 2] = 1.0;
    }

    updateUI();
    render();
}

function toggleAllPart(type, turnOn) {
    saveHistory();
    const arr = getArrayByType(type);
    const count = PART_COUNTS[type];

    while (arr.length < count * 3) arr.push(0, 0, 0);

    for (let i = 0; i < count; i++) {
        if (turnOn) {
            if (arr[i * 3] === 0 && arr[i * 3 + 1] === 0) {
                arr[i * 3] = canvasWidth / 2 + (Math.random() - 0.5) * 100;
                arr[i * 3 + 1] = canvasHeight / 2 + (Math.random() - 0.5) * 100;
            }
            arr[i * 3 + 2] = 1.0;
        } else {
            arr[i * 3 + 2] = 0;
        }
    }

    updateUI();
    render();
    showStatus(turnOn ? `${type} 모두 켜기` : `${type} 모두 끄기`);
}

// ========== 좌표 ==========
function applyCoords() {
    if (selectedPoints.length !== 1) return;
    const x = parseFloat(document.getElementById('coordX').value);
    const y = parseFloat(document.getElementById('coordY').value);
    if (isNaN(x) || isNaN(y)) return;

    saveHistory();
    const p = selectedPoints[0];
    const arr = getArrayByType(p.type);
    arr[p.index * 3] = x;
    arr[p.index * 3 + 1] = y;
    render();
    showStatus('좌표 적용');
}

// ========== JSON ==========
function loadJSON(jsonStr) {
    let data = JSON.parse(jsonStr);
    if (Array.isArray(data)) data = data[0];

    if (data.canvas_width) {
        canvasWidth = data.canvas_width;
        canvasHeight = data.canvas_height || canvasHeight;
        canvas.width = canvasWidth;
        canvas.height = canvasHeight;
        document.getElementById('statusSize').textContent = `${canvasWidth} × ${canvasHeight}`;
    }

    if (data.people && data.people[0]) {
        const p = data.people[0];
        poseData.pose_keypoints_2d = p.pose_keypoints_2d || [];
        poseData.hand_left_keypoints_2d = p.hand_left_keypoints_2d || [];
        poseData.hand_right_keypoints_2d = p.hand_right_keypoints_2d || [];
        poseData.face_keypoints_2d = p.face_keypoints_2d || [];
    }

    resetAllBases();
    resetAllSliders();

    selectedPoints = [];
    saveHistory();
    updateUI();
    render();

    // 캔버스 중앙 정렬 (zoom 100% 유지)
    setTimeout(() => centerCanvas(), 100);

    showStatus('JSON 로드 완료');
}

// ========== 마우스 ==========
function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: (e.clientX - rect.left) * (canvas.width / rect.width),
        y: (e.clientY - rect.top) * (canvas.height / rect.height)
    };
}

function findNearestPoint(x, y) {
    const threshold = 15;
    let nearest = null, minDist = threshold;

    const check = (arr, type, maxPts) => {
        for (let i = 0; i < maxPts && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] <= 0) continue;
            const dist = Math.sqrt((x - arr[i * 3]) ** 2 + (y - arr[i * 3 + 1]) ** 2);
            if (dist < minDist) {
                minDist = dist;
                nearest = { type, index: i, name: getNameByTypeAndIndex(type, i) };
            }
        }
    };

    check(poseData.pose_keypoints_2d, 'body', 24);
    check(poseData.hand_left_keypoints_2d, 'leftHand', 21);
    check(poseData.hand_right_keypoints_2d, 'rightHand', 21);
    check(poseData.face_keypoints_2d, 'face', 68);

    return nearest;
}

function isPointSelected(type, index) {
    return selectedPoints.some(p => p.type === type && p.index === index);
}

function onMouseDown(e) {
    if (e.button === 1 || (e.button === 0 && spacePressed)) {
        e.preventDefault();
        isPanning = true;
        panStartX = e.clientX;
        panStartY = e.clientY;
        const wrapper = document.getElementById('canvasWrapper');
        panScrollStartX = wrapper.scrollLeft;
        panScrollStartY = wrapper.scrollTop;
        canvas.style.cursor = 'grabbing';
        return;
    }

    if (e.button !== 0) return;
    const pos = getMousePos(e);
    const point = findNearestPoint(pos.x, pos.y);

    if (point) {
        if (e.shiftKey) {
            const idx = selectedPoints.findIndex(p => p.type === point.type && p.index === point.index);
            if (idx >= 0) selectedPoints.splice(idx, 1);
            else selectedPoints.push(point);
        } else {
            if (!isPointSelected(point.type, point.index)) selectedPoints = [point];
        }

        isDragging = true;
        dragStartX = pos.x;
        dragStartY = pos.y;
        dragPointsStart = selectedPoints.map(p => {
            const arr = getArrayByType(p.type);
            return { x: arr[p.index * 3], y: arr[p.index * 3 + 1] };
        });
        saveHistory();
        canvas.style.cursor = 'grabbing';
    } else if (e.shiftKey) {
        isBoxSelecting = true;
        boxStartX = boxEndX = pos.x;
        boxStartY = boxEndY = pos.y;
    } else {
        selectedPoints = [];
    }

    updateUI();
    render();
}

function onMouseMove(e) {
    if (isPanning) {
        const wrapper = document.getElementById('canvasWrapper');
        wrapper.scrollLeft = panScrollStartX - (e.clientX - panStartX);
        wrapper.scrollTop = panScrollStartY - (e.clientY - panStartY);
        return;
    }

    const pos = getMousePos(e);
    document.getElementById('statusCoords').textContent = `X: ${Math.round(pos.x)}, Y: ${Math.round(pos.y)}`;

    if (isBoxSelecting) {
        boxEndX = pos.x;
        boxEndY = pos.y;
        render();
        drawSelectionBox();
    } else if (isDragging && selectedPoints.length > 0) {
        const dx = pos.x - dragStartX, dy = pos.y - dragStartY;
        selectedPoints.forEach((p, i) => {
            const arr = getArrayByType(p.type);
            arr[p.index * 3] = dragPointsStart[i].x + dx;
            arr[p.index * 3 + 1] = dragPointsStart[i].y + dy;
        });
        updateCoordInputs();
        render();
    } else {
        const point = findNearestPoint(pos.x, pos.y);
        const tooltip = document.getElementById('tooltip');
        if (point) {
            tooltip.textContent = point.name;
            tooltip.style.display = 'block';
            tooltip.style.left = (e.clientX + 10) + 'px';
            tooltip.style.top = (e.clientY + 10) + 'px';
            canvas.style.cursor = 'grab';
        } else {
            tooltip.style.display = 'none';
            canvas.style.cursor = spacePressed ? 'grab' : 'crosshair';
        }
    }
}

function onMouseUp(e) {
    if (isPanning) {
        isPanning = false;
        canvas.style.cursor = spacePressed ? 'grab' : 'crosshair';
        return;
    }

    if (isBoxSelecting) {
        selectPointsInBox();
        isBoxSelecting = false;
    }
    isDragging = false;
    canvas.style.cursor = 'crosshair';
    updateUI();
    render();
}

function selectPointsInBox() {
    const minX = Math.min(boxStartX, boxEndX), maxX = Math.max(boxStartX, boxEndX);
    const minY = Math.min(boxStartY, boxEndY), maxY = Math.max(boxStartY, boxEndY);
    if (maxX - minX < 5 && maxY - minY < 5) return;

    const check = (arr, type, maxPts) => {
        for (let i = 0; i < maxPts && i * 3 + 2 < arr.length; i++) {
            if (arr[i * 3 + 2] <= 0) continue;
            const x = arr[i * 3], y = arr[i * 3 + 1];
            if (x >= minX && x <= maxX && y >= minY && y <= maxY) {
                if (!isPointSelected(type, i)) {
                    selectedPoints.push({ type, index: i, name: getNameByTypeAndIndex(type, i) });
                }
            }
        }
    };

    check(poseData.pose_keypoints_2d, 'body', 24);
    check(poseData.hand_left_keypoints_2d, 'leftHand', 21);
    check(poseData.hand_right_keypoints_2d, 'rightHand', 21);
    check(poseData.face_keypoints_2d, 'face', 68);
}

function drawSelectionBox() {
    ctx.strokeStyle = '#4a9eff';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);
    ctx.strokeRect(Math.min(boxStartX, boxEndX), Math.min(boxStartY, boxEndY),
        Math.abs(boxEndX - boxStartX), Math.abs(boxEndY - boxStartY));
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(74, 158, 255, 0.1)';
    ctx.fillRect(Math.min(boxStartX, boxEndX), Math.min(boxStartY, boxEndY),
        Math.abs(boxEndX - boxStartX), Math.abs(boxEndY - boxStartY));
}

function onRightClick(e) {
    e.preventDefault();
    const pos = getMousePos(e);
    const point = findNearestPoint(pos.x, pos.y);
    if (point) {
        saveHistory();
        const arr = getArrayByType(point.type);
        arr[point.index * 3 + 2] = 0;
        const idx = selectedPoints.findIndex(p => p.type === point.type && p.index === point.index);
        if (idx >= 0) selectedPoints.splice(idx, 1);
        updateUI();
        render();
        showStatus(`${point.name} 숨김`);
    }
}

function onKeyDown(e) {
    if (e.code === 'Space' && !e.repeat) {
        e.preventDefault();
        spacePressed = true;
        canvas.style.cursor = 'grab';
    }
    else if (e.ctrlKey && e.key === 'z') { e.preventDefault(); undo(); }
    else if (e.ctrlKey && e.key === 'y') { e.preventDefault(); redo(); }
    else if (e.key === 'Delete' && selectedPoints.length > 0) {
        saveHistory();
        selectedPoints.forEach(p => {
            const arr = getArrayByType(p.type);
            arr[p.index * 3 + 2] = 0;
        });
        selectedPoints = [];
        updateUI();
        render();
        showStatus('선택 항목 숨김');
    } else if (e.key === 'Escape') {
        selectedPoints = [];
        updateUI();
        render();
    }
}

function onKeyUp(e) {
    if (e.code === 'Space') {
        spacePressed = false;
        if (!isPanning) {
            canvas.style.cursor = 'crosshair';
        }
    }
}

function applyZoom() {
    const inner = document.getElementById('canvasInner');
    const wrapper = document.getElementById('canvasWrapper');
    const scaledW = canvas.width * zoom;
    const scaledH = canvas.height * zoom;
    canvas.style.width = scaledW + 'px';
    canvas.style.height = scaledH + 'px';
    inner.style.width = Math.max(scaledW, wrapper.clientWidth) + 'px';
    inner.style.height = Math.max(scaledH, wrapper.clientHeight) + 'px';
    canvas.style.marginLeft = Math.max(0, (wrapper.clientWidth - scaledW) / 2) + 'px';
    canvas.style.marginTop = Math.max(0, (wrapper.clientHeight - scaledH) / 2) + 'px';
}

function onWheel(e) {
    e.preventDefault();
    const wrapper = document.getElementById('canvasWrapper');

    // 줌 전: 마우스 아래의 캔버스 좌표를 getBoundingClientRect로 정확하게 계산
    const rect = canvas.getBoundingClientRect();
    const canvasX = (e.clientX - rect.left) * (canvas.width / rect.width);
    const canvasY = (e.clientY - rect.top) * (canvas.height / rect.height);

    // 줌 적용
    zoom = Math.max(0.25, Math.min(4, zoom * (e.deltaY > 0 ? 0.9 : 1.1)));
    applyZoom();

    // 줌 후: 동일한 캔버스 좌표가 화면상 어디에 있는지 다시 계산
    const newRect = canvas.getBoundingClientRect();
    const screenX = newRect.left + canvasX * (newRect.width / canvas.width);
    const screenY = newRect.top + canvasY * (newRect.height / canvas.height);

    // 마우스 아래로 다시 돌아오도록 스크롤 보정
    wrapper.scrollLeft += screenX - e.clientX;
    wrapper.scrollTop += screenY - e.clientY;

    document.getElementById('statusZoom').textContent = Math.round(zoom * 100) + '%';
}

// ========== 줌/캔버스 ==========
function fitCanvasToWrapper() {
    const wrapper = document.getElementById('canvasWrapper');
    const wrapperRect = wrapper.getBoundingClientRect();
    const scaleX = (wrapperRect.width - 40) / canvas.width;
    const scaleY = (wrapperRect.height - 40) / canvas.height;
    zoom = Math.min(scaleX, scaleY, 1);
    applyZoom();
    document.getElementById('statusZoom').textContent = Math.round(zoom * 100) + '%';
}

function centerCanvas() {
    const wrapper = document.getElementById('canvasWrapper');
    const scrollX = (wrapper.scrollWidth - wrapper.clientWidth) / 2;
    const scrollY = (wrapper.scrollHeight - wrapper.clientHeight) / 2;
    wrapper.scrollLeft = Math.max(0, scrollX);
    wrapper.scrollTop = Math.max(0, scrollY);
}

// 창 리사이즈 시 캔버스 중앙 유지
window.addEventListener('resize', () => {
    centerCanvas();
});

// ========== 크기 측정 헬퍼 ==========
function getFaceScale() {
    const kpts = baseFaceData || poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 48 * 3) return canvas.width / 512;

    // 두 눈 중심 사이 거리 (왼눈 36-41, 오른눈 42-47)
    let lx = 0, ly = 0, lc = 0, rx = 0, ry = 0, rc = 0;
    for (let i = 36; i <= 41; i++) {
        if (i * 3 + 2 < kpts.length && kpts[i * 3 + 2] > 0) {
            lx += kpts[i * 3]; ly += kpts[i * 3 + 1]; lc++;
        }
    }
    for (let i = 42; i <= 47; i++) {
        if (i * 3 + 2 < kpts.length && kpts[i * 3 + 2] > 0) {
            rx += kpts[i * 3]; ry += kpts[i * 3 + 1]; rc++;
        }
    }
    if (lc > 0 && rc > 0) {
        lx /= lc; ly /= lc; rx /= rc; ry /= rc;
        const eyeDist = Math.sqrt((rx - lx) ** 2 + (ry - ly) ** 2);
        if (eyeDist > 1) return eyeDist / 40;
    }
    return canvas.width / 512;
}

function getBodyScale() {
    const kpts = poseData.pose_keypoints_2d;
    if (!kpts || kpts.length < 24 * 3) return canvas.width / 512;

    // 어깨 폭 기준
    const rs = JOINT.R_SHOULDER, ls = JOINT.L_SHOULDER;
    if (kpts[rs * 3 + 2] > 0 && kpts[ls * 3 + 2] > 0) {
        const sw = Math.sqrt((kpts[rs * 3] - kpts[ls * 3]) ** 2 + (kpts[rs * 3 + 1] - kpts[ls * 3 + 1]) ** 2);
        if (sw > 1) return sw / 100;
    }

    // fallback: 목→엉덩이 거리
    const neck = JOINT.NECK, rh = JOINT.R_HIP, lh = JOINT.L_HIP;
    if (kpts[neck * 3 + 2] > 0) {
        const hipX = (kpts[rh * 3 + 2] > 0 && kpts[lh * 3 + 2] > 0) ?
            (kpts[rh * 3] + kpts[lh * 3]) / 2 : (kpts[rh * 3 + 2] > 0 ? kpts[rh * 3] : kpts[lh * 3]);
        const hipY = (kpts[rh * 3 + 2] > 0 && kpts[lh * 3 + 2] > 0) ?
            (kpts[rh * 3 + 1] + kpts[lh * 3 + 1]) / 2 : (kpts[rh * 3 + 2] > 0 ? kpts[rh * 3 + 1] : kpts[lh * 3 + 1]);
        const torso = Math.sqrt((hipX - kpts[neck * 3]) ** 2 + (hipY - kpts[neck * 3 + 1]) ** 2);
        if (torso > 1) return torso / 150;
    }

    return canvas.width / 512;
}

// ========== 시선 & 표정 ==========
let baseFaceData = null;

function saveBaseFace() {
    if (!baseFaceData && poseData.face_keypoints_2d.length > 0) {
        baseFaceData = [...poseData.face_keypoints_2d];
    }
}

function applyGaze() {
    saveBaseFace();
    if (!baseFaceData || baseFaceData.length < 68 * 3) return;

    const gazeX = parseFloat(document.getElementById('gazeX').value);
    const gazeY = parseFloat(document.getElementById('gazeY').value);
    const scale = getFaceScale();

    document.getElementById('gazeXValue').textContent = gazeX;
    document.getElementById('gazeYValue').textContent = gazeY;

    for (let i = 36; i <= 47; i++) {
        if (i * 3 + 2 < poseData.face_keypoints_2d.length) {
            poseData.face_keypoints_2d[i * 3] = baseFaceData[i * 3] + gazeX * scale;
            poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + gazeY * scale;
        }
    }

    render();
}

function applyExpression() {
    saveBaseFace();
    if (!baseFaceData || baseFaceData.length < 68 * 3) return;

    const mouthOpen = parseFloat(document.getElementById('mouthOpen').value);
    const eyeSize = parseFloat(document.getElementById('eyeClose').value);
    const scale = getFaceScale();

    document.getElementById('mouthOpenValue').textContent = mouthOpen;
    document.getElementById('eyeCloseValue').textContent = eyeSize;

    // 입: 양수=벌리기, 음수=다물기
    if (mouthOpen >= 0) {
        // 벌리기: 윗입술 올리고 아랫입술 내리기
        for (let i = 48; i < 55; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - mouthOpen * 0.3 * scale;
            }
        }
        for (let i = 54; i < 60; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + mouthOpen * 0.7 * scale;
            }
        }
        // 안쪽 입도 동기화
        for (let i = 60; i < 65; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - mouthOpen * 0.2 * scale;
            }
        }
        for (let i = 64; i < 68; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + mouthOpen * 0.5 * scale;
            }
        }
    } else {
        // 다물기: 윗입술과 아랫입술 모두 중심으로 모음
        const closeFactor = Math.abs(mouthOpen) / 10;
        // 바깥쪽 입
        for (let i = 48; i < 60; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                let mouthCenterY = 0, mc = 0;
                for (let k = 48; k < 60; k++) {
                    if (k * 3 + 1 < baseFaceData.length) { mouthCenterY += baseFaceData[k * 3 + 1]; mc++; }
                }
                mouthCenterY /= mc;
                const dy = baseFaceData[i * 3 + 1] - mouthCenterY;
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - dy * closeFactor * 0.5;
            }
        }
        // 안쪽 입
        for (let i = 60; i < 68; i++) {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                let mouthCenterY = 0, mc = 0;
                for (let k = 60; k < 68; k++) {
                    if (k * 3 + 1 < baseFaceData.length) { mouthCenterY += baseFaceData[k * 3 + 1]; mc++; }
                }
                mouthCenterY /= mc;
                const dy = baseFaceData[i * 3 + 1] - mouthCenterY;
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - dy * closeFactor * 0.7;
            }
        }
    }

    // 눈: 양수=감기, 음수=크게 뜨기
    if (eyeSize >= 0) {
        const eyeCloseAmount = eyeSize / 100 * 8 * scale;
        // 위 눈꺼풀 내리기
        [37, 38, 43, 44].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + eyeCloseAmount;
            }
        });
        // 아래 눈꺼풀 올리기
        [40, 41, 46, 47].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - eyeCloseAmount * 0.3;
            }
        });
    } else {
        const eyeOpenAmount = Math.abs(eyeSize) / 100 * 6 * scale;
        // 위 눈꺼풀 올리기
        [37, 38, 43, 44].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] - eyeOpenAmount;
            }
        });
        // 아래 눈꺼풀 내리기
        [40, 41, 46, 47].forEach(i => {
            if (i * 3 + 1 < poseData.face_keypoints_2d.length) {
                poseData.face_keypoints_2d[i * 3 + 1] = baseFaceData[i * 3 + 1] + eyeOpenAmount * 0.4;
            }
        });
    }

    render();
}

function resetExpression() {
    if (baseFaceData) {
        poseData.face_keypoints_2d = [...baseFaceData];
        baseFaceData = null;
    }
    document.getElementById('gazeX').value = 0;
    document.getElementById('gazeY').value = 0;
    document.getElementById('mouthOpen').value = 0;
    document.getElementById('eyeClose').value = 0;
    document.getElementById('gazeXValue').textContent = '0';
    document.getElementById('gazeYValue').textContent = '0';
    document.getElementById('mouthOpenValue').textContent = '0';
    document.getElementById('eyeCloseValue').textContent = '0';
    render();
    showStatus('표정 초기화');
}

// ========== FK 관절 회전 ==========
let fkBasePose = null;
let fkLastAngles = {};

function ensureFKBase() {
    if (!fkBasePose) {
        fkBasePose = {
            body: [...poseData.pose_keypoints_2d],
            leftHand: [...poseData.hand_left_keypoints_2d],
            rightHand: [...poseData.hand_right_keypoints_2d],
            face: [...poseData.face_keypoints_2d]
        };
        fkLastAngles = {};
    }
}

function restoreFKBase() {
    if (fkBasePose) {
        poseData.pose_keypoints_2d = [...fkBasePose.body];
        poseData.hand_left_keypoints_2d = [...fkBasePose.leftHand];
        poseData.hand_right_keypoints_2d = [...fkBasePose.rightHand];
        poseData.face_keypoints_2d = [...fkBasePose.face];
    }
}

function applyAllFK() {
    ensureFKBase();
    restoreFKBase();

    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 24 * 3) { render(); return; }

    // Head
    const headAngle = parseFloat(document.getElementById('fkHead').value);
    if (headAngle !== 0) {
        const neckX = kpts[JOINT.NECK * 3];
        const neckY = kpts[JOINT.NECK * 3 + 1];
        const rad = headAngle * Math.PI / 180;
        const cos = Math.cos(rad), sin = Math.sin(rad);
        [JOINT.NOSE, JOINT.R_EYE, JOINT.L_EYE, JOINT.R_EAR, JOINT.L_EAR].forEach(j => {
            const x = kpts[j * 3] - neckX;
            const y = kpts[j * 3 + 1] - neckY;
            kpts[j * 3] = neckX + x * cos - y * sin;
            kpts[j * 3 + 1] = neckY + x * sin + y * cos;
        });
        rotateFaceAroundPivot(neckX, neckY, cos, sin);
    }

    // Both arms
    ['right', 'left'].forEach(side => {
        const prefix = side === 'right' ? 'R' : 'L';
        const shoulderAngle = parseFloat(document.getElementById(`fk${prefix}Shoulder`).value);
        const elbowAngle = parseFloat(document.getElementById(`fk${prefix}Elbow`).value);
        const wristAngle = parseFloat(document.getElementById(`fk${prefix}Wrist`).value);

        const SHOULDER = side === 'right' ? JOINT.R_SHOULDER : JOINT.L_SHOULDER;
        const ELBOW = side === 'right' ? JOINT.R_ELBOW : JOINT.L_ELBOW;
        const WRIST = side === 'right' ? JOINT.R_WRIST : JOINT.L_WRIST;

        if (shoulderAngle !== 0) {
            const pivotX = kpts[SHOULDER * 3];
            const pivotY = kpts[SHOULDER * 3 + 1];
            const rad = shoulderAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            [ELBOW, WRIST].forEach(j => {
                const x = kpts[j * 3] - pivotX;
                const y = kpts[j * 3 + 1] - pivotY;
                kpts[j * 3] = pivotX + x * cos - y * sin;
                kpts[j * 3 + 1] = pivotY + x * sin + y * cos;
            });
            rotateHandAroundPivot(side, pivotX, pivotY, cos, sin);
        }

        if (elbowAngle !== 0) {
            const pivotX = kpts[ELBOW * 3];
            const pivotY = kpts[ELBOW * 3 + 1];
            const rad = elbowAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            const x = kpts[WRIST * 3] - pivotX;
            const y = kpts[WRIST * 3 + 1] - pivotY;
            kpts[WRIST * 3] = pivotX + x * cos - y * sin;
            kpts[WRIST * 3 + 1] = pivotY + x * sin + y * cos;
            rotateHandAroundPivot(side, pivotX, pivotY, cos, sin);
        }

        if (wristAngle !== 0) {
            const pivotX = kpts[WRIST * 3];
            const pivotY = kpts[WRIST * 3 + 1];
            const rad = wristAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            rotateHandAroundPivot(side, pivotX, pivotY, cos, sin);
        }
    });

    // Both legs
    ['right', 'left'].forEach(side => {
        const prefix = side === 'right' ? 'R' : 'L';
        const hipAngle = parseFloat(document.getElementById(`fk${prefix}Hip`).value);
        const kneeAngle = parseFloat(document.getElementById(`fk${prefix}Knee`).value);

        const HIP = side === 'right' ? JOINT.R_HIP : JOINT.L_HIP;
        const KNEE = side === 'right' ? JOINT.R_KNEE : JOINT.L_KNEE;
        const ANKLE = side === 'right' ? JOINT.R_ANKLE : JOINT.L_ANKLE;
        const FOOT = side === 'right'
            ? [JOINT.R_BIGTOE, JOINT.R_SMALLTOE, JOINT.R_HEEL]
            : [JOINT.L_BIGTOE, JOINT.L_SMALLTOE, JOINT.L_HEEL];

        if (hipAngle !== 0) {
            const pivotX = kpts[HIP * 3];
            const pivotY = kpts[HIP * 3 + 1];
            const rad = hipAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            [KNEE, ANKLE, ...FOOT].forEach(j => {
                if (j * 3 + 2 >= kpts.length) return;
                const x = kpts[j * 3] - pivotX;
                const y = kpts[j * 3 + 1] - pivotY;
                kpts[j * 3] = pivotX + x * cos - y * sin;
                kpts[j * 3 + 1] = pivotY + x * sin + y * cos;
            });
        }

        if (kneeAngle !== 0) {
            const pivotX = kpts[KNEE * 3];
            const pivotY = kpts[KNEE * 3 + 1];
            const rad = kneeAngle * Math.PI / 180;
            const cos = Math.cos(rad), sin = Math.sin(rad);
            [ANKLE, ...FOOT].forEach(j => {
                if (j * 3 + 2 >= kpts.length) return;
                const x = kpts[j * 3] - pivotX;
                const y = kpts[j * 3 + 1] - pivotY;
                kpts[j * 3] = pivotX + x * cos - y * sin;
                kpts[j * 3 + 1] = pivotY + x * sin + y * cos;
            });
        }
    });

    render();
}

function applyFKHead() {
    document.getElementById('fkHeadValue').textContent = document.getElementById('fkHead').value + '°';
    applyAllFK();
}

function applyFKArm(side) {
    const prefix = side === 'right' ? 'R' : 'L';
    document.getElementById(`fk${prefix}ShoulderValue`).textContent = document.getElementById(`fk${prefix}Shoulder`).value + '°';
    document.getElementById(`fk${prefix}ElbowValue`).textContent = document.getElementById(`fk${prefix}Elbow`).value + '°';
    document.getElementById(`fk${prefix}WristValue`).textContent = document.getElementById(`fk${prefix}Wrist`).value + '°';
    applyAllFK();
}

function applyFKLeg(side) {
    const prefix = side === 'right' ? 'R' : 'L';
    document.getElementById(`fk${prefix}HipValue`).textContent = document.getElementById(`fk${prefix}Hip`).value + '°';
    document.getElementById(`fk${prefix}KneeValue`).textContent = document.getElementById(`fk${prefix}Knee`).value + '°';
    applyAllFK();
}

function resetFK() {
    if (fkBasePose) {
        poseData.pose_keypoints_2d = [...fkBasePose.body];
        poseData.hand_left_keypoints_2d = [...fkBasePose.leftHand];
        poseData.hand_right_keypoints_2d = [...fkBasePose.rightHand];
        poseData.face_keypoints_2d = [...fkBasePose.face];
    }

    ['fkHead', 'fkRShoulder', 'fkRElbow', 'fkRWrist',
     'fkLShoulder', 'fkLElbow', 'fkLWrist',
     'fkRHip', 'fkRKnee', 'fkLHip', 'fkLKnee'].forEach(id => {
        document.getElementById(id).value = 0;
        document.getElementById(id + 'Value').textContent = '0°';
    });

    render();
    showStatus('관절 초기화');
}

// ========== 손 프리셋 ==========

// 1단계: 프리셋 원본 복원 시스템
function ensureHandBase(side) {
    const key = side === 'left' ? 'left' : 'right';
    if (!handPresetBase[key]) {
        const kpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
        if (kpts && kpts.length >= 3) {
            handPresetBase[key] = [...kpts];
        }
    }
}

function restoreHandBase(side) {
    const key = side === 'left' ? 'left' : 'right';
    if (handPresetBase[key]) {
        if (side === 'left') {
            poseData.hand_left_keypoints_2d = [...handPresetBase[key]];
        } else {
            poseData.hand_right_keypoints_2d = [...handPresetBase[key]];
        }
    }
}

function resetHandPreset() {
    if (handPresetBase.left) {
        poseData.hand_left_keypoints_2d = [...handPresetBase.left];
        handPresetBase.left = null;
    }
    if (handPresetBase.right) {
        poseData.hand_right_keypoints_2d = [...handPresetBase.right];
        handPresetBase.right = null;
    }
    render();
    updateUI();
    showStatus('손 프리셋 초기화');
}

// 2단계: getHandScale 개선
function getHandScale(side) {
    const key = side === 'left' ? 'left' : 'right';
    const kpts = handPresetBase[key] ||
        (side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d);
    if (!kpts || kpts.length < 13 * 3) return Math.max(0.3, Math.min(canvas.width / 512, 5));

    // 손목→중지끝(12) 거리 우선
    if (kpts[0 * 3 + 2] > 0 && kpts[12 * 3 + 2] > 0) {
        const dx = kpts[12 * 3] - kpts[0 * 3];
        const dy = kpts[12 * 3 + 1] - kpts[0 * 3 + 1];
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 1) return Math.max(0.3, Math.min(dist / 50, 5));
    }

    // 손목→중지MCP(9) 거리
    if (kpts[0 * 3 + 2] > 0 && kpts[9 * 3 + 2] > 0) {
        const dx = kpts[9 * 3] - kpts[0 * 3];
        const dy = kpts[9 * 3 + 1] - kpts[0 * 3 + 1];
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 1) return Math.max(0.3, Math.min(dist / 18, 5));
    }

    return Math.max(0.3, Math.min(canvas.width / 512, 5));
}

// 4단계: 손바닥/손등 방향 감지
function detectCurlSign(kpts, side) {
    if (!kpts || kpts.length < 10 * 3) {
        return side === 'right' ? 1 : -1;
    }

    const wristX = kpts[0 * 3], wristY = kpts[0 * 3 + 1];

    // 중지MCP(9)로 midDir 벡터
    if (kpts[9 * 3 + 2] <= 0 || kpts[0 * 3 + 2] <= 0) {
        return side === 'right' ? 1 : -1;
    }
    const vec1x = kpts[9 * 3] - wristX;
    const vec1y = kpts[9 * 3 + 1] - wristY;

    // 엄지CMC(1)로 엄지 벡터
    if (kpts[1 * 3 + 2] <= 0) {
        return side === 'right' ? 1 : -1;
    }
    const vec2x = kpts[1 * 3] - wristX;
    const vec2y = kpts[1 * 3 + 1] - wristY;

    const cross = vec1x * vec2y - vec1y * vec2x;

    // 오른손: cross > 0 → 손바닥(양수), cross < 0 → 손등(음수)
    // 왼손: 반대
    if (side === 'right') {
        return cross >= 0 ? 1 : -1;
    } else {
        return cross >= 0 ? -1 : 1;
    }
}

function applyHandPreset(which, preset) {
    const hands = which === 'both' ? ['left', 'right'] : [which];
    saveHistory();

    hands.forEach(side => {
        // 1단계: base 저장 후 복원
        ensureHandBase(side);
        restoreHandBase(side);

        const kpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
        if (!kpts || kpts.length < 3) return;

        // 2단계: 스케일 계산 (항상 base에서)
        const scale = getHandScale(side);
        const wristX = kpts[0 * 3];
        const wristY = kpts[0 * 3 + 1];

        // 4단계: curl 방향 감지 (base 데이터에서)
        const baseKpts = handPresetBase[side] || kpts;
        const curlSign = detectCurlSign(baseKpts, side);

        const midDir = kpts[9 * 3 + 2] > 0 ?
            Math.atan2(kpts[9 * 3 + 1] - wristY, kpts[9 * 3] - wristX) :
            (side === 'left' ? Math.PI / 2 : -Math.PI / 2);

        const fingers = [
            { start: 1, joints: 4, angleOffset: -60, name: 'thumb' },
            { start: 5, joints: 4, angleOffset: -15, name: 'index' },
            { start: 9, joints: 4, angleOffset: 0, name: 'middle' },
            { start: 13, joints: 4, angleOffset: 15, name: 'ring' },
            { start: 17, joints: 4, angleOffset: 35, name: 'pinky' }
        ];

        // 5단계: curl 값 강화
        const curlSettings = {
            open: { thumb: 5, index: 3, middle: 3, ring: 3, pinky: 5 },
            fist: { thumb: 100, index: 150, middle: 150, ring: 150, pinky: 150 },
            point: { thumb: 100, index: 0, middle: 150, ring: 150, pinky: 150 },
            peace: { thumb: 100, index: 0, middle: 0, ring: 150, pinky: 150 },
            ok: { thumb: 50, index: 50, middle: 0, ring: 0, pinky: 0 },
            thumbup: { thumb: 0, index: 150, middle: 150, ring: 150, pinky: 150 }
        };

        const curls = curlSettings[preset] || curlSettings.open;

        // 3단계: 관절별 가중치
        const jointWeights = [0.9, 1.2, 0.8, 0.3]; // MCP, PIP, DIP, tip

        const baseLengths = { thumb: [12, 10, 8, 6], other: [18, 14, 10, 8] };

        fingers.forEach(finger => {
            let baseAngle = midDir + (finger.angleOffset * Math.PI / 180);
            const rawCurl = curls[finger.name] * Math.PI / 180;
            // 4단계: curl 방향에 curlSign 적용
            const curl = rawCurl * curlSign;

            let prevX = wristX;
            let prevY = wristY;
            let currentAngle = baseAngle;

            if (finger.name === 'thumb') {
                if (preset === 'thumbup') {
                    currentAngle = midDir - (Math.PI / 2) * curlSign;
                }
                const thumbOffsetAngle = (preset === 'thumbup') ?
                    midDir - (Math.PI / 3) * curlSign :
                    baseAngle + (Math.PI / 6) * curlSign;
                prevX = wristX + Math.cos(thumbOffsetAngle) * 15 * scale;
                prevY = wristY + Math.sin(thumbOffsetAngle) * 15 * scale;
            }

            const lengths = finger.name === 'thumb' ? baseLengths.thumb : baseLengths.other;

            for (let j = 0; j < finger.joints; j++) {
                const idx = finger.start + j;
                if (idx * 3 + 2 >= kpts.length) continue;

                // 3단계: 관절별 가중치 차등 적용
                currentAngle += curl * 0.45 * jointWeights[j];

                const len = (lengths[j] || 10) * scale;
                kpts[idx * 3] = prevX + Math.cos(currentAngle) * len;
                kpts[idx * 3 + 1] = prevY + Math.sin(currentAngle) * len;
                kpts[idx * 3 + 2] = 1.0;

                prevX = kpts[idx * 3];
                prevY = kpts[idx * 3 + 1];
            }
        });

        // ok: 엄지와 검지 끝이 만나도록 특별 처리
        if (preset === 'ok') {
            const thumbTip = 4, indexTip = 8;
            if (thumbTip * 3 + 2 < kpts.length && indexTip * 3 + 2 < kpts.length) {
                const meetX = (kpts[thumbTip * 3] + kpts[indexTip * 3]) / 2;
                const meetY = (kpts[thumbTip * 3 + 1] + kpts[indexTip * 3 + 1]) / 2;
                kpts[thumbTip * 3] = meetX;
                kpts[thumbTip * 3 + 1] = meetY;
                kpts[indexTip * 3] = meetX;
                kpts[indexTip * 3 + 1] = meetY;
            }
        }
    });

    render();
    updateUI();
    showStatus(`손 프리셋: ${preset}`);
}

// ========== 전체 변형 ==========
function scalePose(factor, pivot = 'center') {
    saveHistory();

    let pivotX, pivotY;
    const kpts = poseData.pose_keypoints_2d;

    if (pivot === 'neck' && kpts.length > JOINT.NECK * 3 + 2 && kpts[JOINT.NECK * 3 + 2] > 0) {
        pivotX = kpts[JOINT.NECK * 3];
        pivotY = kpts[JOINT.NECK * 3 + 1];
    } else {
        pivotX = canvasWidth / 2;
        pivotY = canvasHeight / 2;
    }

    for (let i = 0; i < kpts.length; i += 3) {
        if (kpts[i + 2] <= 0) continue;
        kpts[i] = pivotX + (kpts[i] - pivotX) * factor;
        kpts[i + 1] = pivotY + (kpts[i + 1] - pivotY) * factor;
    }

    [poseData.hand_left_keypoints_2d, poseData.hand_right_keypoints_2d].forEach(hkpts => {
        if (!hkpts) return;
        for (let i = 0; i < hkpts.length; i += 3) {
            if (hkpts[i + 2] <= 0) continue;
            hkpts[i] = pivotX + (hkpts[i] - pivotX) * factor;
            hkpts[i + 1] = pivotY + (hkpts[i + 1] - pivotY) * factor;
        }
    });

    const fkpts = poseData.face_keypoints_2d;
    if (fkpts) {
        for (let i = 0; i < fkpts.length; i += 3) {
            if (fkpts[i + 2] <= 0) continue;
            fkpts[i] = pivotX + (fkpts[i] - pivotX) * factor;
            fkpts[i + 1] = pivotY + (fkpts[i + 1] - pivotY) * factor;
        }
    }

    resetAllBases();
    render();
    showStatus(`스케일 ${Math.round(factor * 100)}% (${pivot})`);
}

// ========== Fake 3D (부위별) ==========
let fake3dBasePose = null;

const FAKE3D_PARTS = {
    head: {
        rightJoints: [JOINT.R_EYE, JOINT.R_EAR],
        leftJoints: [JOINT.L_EYE, JOINT.L_EAR],
        centerJoints: [JOINT.NOSE],
        includesFace: true,
        includesHands: false,
        getPivot: (kpts) => ({ x: kpts[JOINT.NECK * 3], y: kpts[JOINT.NECK * 3 + 1] })
    },
    shoulder: {
        rightJoints: [JOINT.R_SHOULDER, JOINT.R_ELBOW, JOINT.R_WRIST],
        leftJoints: [JOINT.L_SHOULDER, JOINT.L_ELBOW, JOINT.L_WRIST],
        centerJoints: [],
        includesFace: false,
        includesHands: true,
        getPivot: (kpts) => ({ x: kpts[JOINT.NECK * 3], y: kpts[JOINT.NECK * 3 + 1] })
    },
    waist: {
        rightJoints: [JOINT.R_SHOULDER, JOINT.R_ELBOW, JOINT.R_WRIST, JOINT.R_EYE, JOINT.R_EAR],
        leftJoints: [JOINT.L_SHOULDER, JOINT.L_ELBOW, JOINT.L_WRIST, JOINT.L_EYE, JOINT.L_EAR],
        centerJoints: [JOINT.NECK, JOINT.NOSE],
        includesFace: true,
        includesHands: true,
        getPivot: (kpts) => ({
            x: (kpts[JOINT.R_HIP * 3] + kpts[JOINT.L_HIP * 3]) / 2,
            y: (kpts[JOINT.R_HIP * 3 + 1] + kpts[JOINT.L_HIP * 3 + 1]) / 2
        })
    },
    pelvis: {
        rightJoints: [JOINT.R_HIP, JOINT.R_KNEE, JOINT.R_ANKLE, JOINT.R_BIGTOE, JOINT.R_SMALLTOE, JOINT.R_HEEL],
        leftJoints: [JOINT.L_HIP, JOINT.L_KNEE, JOINT.L_ANKLE, JOINT.L_BIGTOE, JOINT.L_SMALLTOE, JOINT.L_HEEL],
        centerJoints: [],
        includesFace: false,
        includesHands: false,
        getPivot: (kpts) => ({
            x: (kpts[JOINT.R_HIP * 3] + kpts[JOINT.L_HIP * 3]) / 2,
            y: (kpts[JOINT.R_HIP * 3 + 1] + kpts[JOINT.L_HIP * 3 + 1]) / 2
        })
    },
    leg: {
        rightJoints: [JOINT.R_ANKLE, JOINT.R_BIGTOE, JOINT.R_SMALLTOE, JOINT.R_HEEL],
        leftJoints: [JOINT.L_ANKLE, JOINT.L_BIGTOE, JOINT.L_SMALLTOE, JOINT.L_HEEL],
        centerJoints: [],
        includesFace: false,
        includesHands: false,
        getPivot: (kpts) => ({
            x: (kpts[JOINT.R_KNEE * 3] + kpts[JOINT.L_KNEE * 3]) / 2,
            y: (kpts[JOINT.R_KNEE * 3 + 1] + kpts[JOINT.L_KNEE * 3 + 1]) / 2
        })
    }
};

function ensureFake3DBase() {
    if (!fake3dBasePose) {
        fake3dBasePose = {
            body: [...poseData.pose_keypoints_2d],
            leftHand: [...poseData.hand_left_keypoints_2d],
            rightHand: [...poseData.hand_right_keypoints_2d],
            face: [...poseData.face_keypoints_2d]
        };
    }
}

function applyFake3DPartTurn(partDef, turnValue, kpts, bodyS, faceS) {
    if (turnValue === 0) return;
    const turnFactor = turnValue / 30;
    const pivot = partDef.getPivot(kpts);

    partDef.rightJoints.forEach(j => {
        if (j * 3 + 2 >= kpts.length || kpts[j * 3 + 2] <= 0) return;
        const dx = kpts[j * 3] - pivot.x;
        kpts[j * 3] = pivot.x + dx * (1 - turnFactor * 0.3);
    });

    partDef.leftJoints.forEach(j => {
        if (j * 3 + 2 >= kpts.length || kpts[j * 3 + 2] <= 0) return;
        const dx = kpts[j * 3] - pivot.x;
        kpts[j * 3] = pivot.x + dx * (1 + turnFactor * 0.3);
    });

    partDef.centerJoints.forEach(j => {
        if (j * 3 + 2 >= kpts.length || kpts[j * 3 + 2] <= 0) return;
        kpts[j * 3] += turnFactor * 10 * bodyS;
    });

    if (partDef.includesHands) {
        const rScale = 1 - turnFactor * 0.3;
        const lScale = 1 + turnFactor * 0.3;
        applyFake3DScaleHand('right', pivot.x, rScale);
        applyFake3DScaleHand('left', pivot.x, lScale);
    }

    if (partDef.includesFace) {
        applyFake3DTurnFace(pivot.x, turnFactor, faceS);
    }
}

function applyFake3DPartLean(partDef, leanValue, kpts, bodyS, faceS) {
    if (leanValue === 0) return;
    const leanFactor = leanValue / 30;
    const allJoints = [...partDef.rightJoints, ...partDef.leftJoints, ...partDef.centerJoints];

    allJoints.forEach(j => {
        if (j * 3 + 2 >= kpts.length || kpts[j * 3 + 2] <= 0) return;
        kpts[j * 3 + 1] += leanFactor * 20 * bodyS;
    });

    if (partDef.includesHands) {
        ['left', 'right'].forEach(side => {
            const hkpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
            if (!hkpts || hkpts.length < 3) return;
            const numPts = Math.floor(hkpts.length / 3);
            for (let i = 0; i < numPts; i++) {
                if (hkpts[i * 3 + 2] <= 0) continue;
                hkpts[i * 3 + 1] += leanFactor * 20 * bodyS;
            }
        });
    }

    if (partDef.includesFace) {
        applyFake3DLeanFace(leanFactor, faceS);
    }
}

function applyFake3DScaleHand(side, centerX, scaleFactor) {
    const kpts = side === 'left' ? poseData.hand_left_keypoints_2d : poseData.hand_right_keypoints_2d;
    if (!kpts || kpts.length < 3) return;
    const numPts = Math.floor(kpts.length / 3);
    for (let i = 0; i < numPts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        const dx = kpts[i * 3] - centerX;
        kpts[i * 3] = centerX + dx * scaleFactor;
    }
}

function applyFake3DTurnFace(centerX, turnFactor, faceS) {
    const kpts = poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 3) return;
    const numPts = Math.floor(kpts.length / 3);
    for (let i = 0; i < numPts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        const dx = kpts[i * 3] - centerX;
        kpts[i * 3] = centerX + dx * (1 - Math.abs(turnFactor) * 0.15) + turnFactor * 8 * faceS;
    }
}

function applyFake3DLeanFace(leanFactor, faceS) {
    const kpts = poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 3) return;
    const numPts = Math.floor(kpts.length / 3);
    for (let i = 0; i < numPts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        kpts[i * 3 + 1] += leanFactor * 15 * faceS;
    }
}

function updateFake3DSliderDisplay(partName) {
    ['Turn', 'Lean'].forEach(axis => {
        const id = `fake3d${partName}${axis}`;
        const el = document.getElementById(id);
        const valEl = document.getElementById(id + 'Value');
        if (el && valEl) valEl.textContent = el.value;
    });
}

function applyAllFake3D() {
    ensureFake3DBase();
    if (!fake3dBasePose) return;

    // 1. base에서 전체 복원
    poseData.pose_keypoints_2d = [...fake3dBasePose.body];
    poseData.hand_left_keypoints_2d = [...fake3dBasePose.leftHand];
    poseData.hand_right_keypoints_2d = [...fake3dBasePose.rightHand];
    poseData.face_keypoints_2d = [...fake3dBasePose.face];

    const kpts = poseData.pose_keypoints_2d;
    if (kpts.length < 24 * 3) { render(); return; }

    const bodyS = getBodyScale();
    const faceS = getFaceScale();

    // 2. 아래→위 순서: 다리 → 골반 → 허리 → 어깨 → 머리
    const applyOrder = ['leg', 'pelvis', 'waist', 'shoulder', 'head'];
    const partNames = { leg: 'Leg', pelvis: 'Pelvis', waist: 'Waist', shoulder: 'Shoulder', head: 'Head' };

    applyOrder.forEach(key => {
        const name = partNames[key];
        const turnEl = document.getElementById(`fake3d${name}Turn`);
        const leanEl = document.getElementById(`fake3d${name}Lean`);
        const turn = turnEl ? parseFloat(turnEl.value) : 0;
        const lean = leanEl ? parseFloat(leanEl.value) : 0;

        applyFake3DPartTurn(FAKE3D_PARTS[key], turn, kpts, bodyS, faceS);
        applyFake3DPartLean(FAKE3D_PARTS[key], lean, kpts, bodyS, faceS);
    });

    render();
}

function onFake3DChange(partName) {
    updateFake3DSliderDisplay(partName);
    applyAllFake3D();
}

function resetFake3D() {
    if (fake3dBasePose) {
        poseData.pose_keypoints_2d = [...fake3dBasePose.body];
        poseData.hand_left_keypoints_2d = [...fake3dBasePose.leftHand];
        poseData.hand_right_keypoints_2d = [...fake3dBasePose.rightHand];
        poseData.face_keypoints_2d = [...fake3dBasePose.face];
        fake3dBasePose = null;
    }

    ['Head', 'Shoulder', 'Waist', 'Pelvis', 'Leg'].forEach(part => {
        ['Turn', 'Lean'].forEach(axis => {
            const id = `fake3d${part}${axis}`;
            const el = document.getElementById(id);
            if (el) el.value = 0;
            const valEl = document.getElementById(id + 'Value');
            if (valEl) valEl.textContent = '0';
        });
    });

    render();
    showStatus('Fake 3D 초기화');
}

// ========== 렌더링 ==========
function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const lineThickness = parseInt(document.getElementById('lineThickness').value);
    const pointRadius = parseInt(document.getElementById('pointRadius').value);

    // 배경
    if (showBackground && backgroundImage) {
        const opacity = parseInt(document.getElementById('bgOpacity').value) / 100;
        ctx.globalAlpha = opacity;
        ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);
        ctx.globalAlpha = 1.0;
    }

    // 스켈레톤
    if (showSkeleton) {
        drawBody(lineThickness, pointRadius);
        drawHand(poseData.hand_left_keypoints_2d, Math.max(1, lineThickness - 2), pointRadius);
        drawHand(poseData.hand_right_keypoints_2d, Math.max(1, lineThickness - 2), pointRadius);
        drawFace(Math.max(1, pointRadius - 1));
    }

    // 선택 하이라이트는 항상 표시
    drawSelectionHighlight(pointRadius);
}

// HSL(h, 100%, 50%) → RGB → R/B swap to match renderer BGR output
function hslToSwappedRgb(hDeg) {
    const x = 1 - Math.abs((hDeg / 60) % 2 - 1);
    let r, g, b;
    if (hDeg < 60)       { r = 1; g = x; b = 0; }
    else if (hDeg < 120) { r = x; g = 1; b = 0; }
    else if (hDeg < 180) { r = 0; g = 1; b = x; }
    else if (hDeg < 240) { r = 0; g = x; b = 1; }
    else if (hDeg < 300) { r = x; g = 0; b = 1; }
    else                 { r = 1; g = 0; b = x; }
    return `rgb(${Math.round(b * 255)},${Math.round(g * 255)},${Math.round(r * 255)})`;
}

// drawBody - util.py draw_bodypose_with_feet()와 동일한 렌더링 로직
//
// [렌더러 대응]
// - 선 그리기: util.py는 cv2.fillConvexPoly(ellipse2Poly)로 두꺼운 타원형 선을 그림
//   에디터는 canvas lineTo + round lineCap으로 유사하게 표현
// - 선 색상: LIMB_SEQ 인덱스(i)에 따라 BODY_COLORS[i] 사용
//   발 관절이 포함된 연결은 ankle 색상으로 통일 (util.py와 동일)
//   - LEFT_FOOT(LAnkle=13, LBigToe=18, LSmToe=19, LHeel=20) → BODY_COLORS[13]
//   - RIGHT_FOOT(RAnkle=10, RBigToe=21, RSmToe=22, RHeel=23) → BODY_COLORS[10]
// - 선 두께: [0~16] body → lineThickness, [17~24] feet → lineThickness-2
//   util.py: body → stickwidth(4+mod), feet → feet_stickwidth(2+hand_mod)
// - opacity: util.py는 선 그린 후 canvas *= pose_opacity, 그 위에 점을 그림
//   에디터: ctx.globalAlpha = poseOpacity로 선, 점은 globalAlpha=1.0 (동일 효과)
// - 점 크기: [0~17] body → pointRadius, [18~23] feet → pointRadius-1
//   util.py: body → dot_radius(4+mod), feet(>=18) → feet_dot_radius(4+hand_dot_mod)
function drawBody(lineThickness, pointRadius) {
    const kpts = poseData.pose_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const poseOpacity = parseInt(document.getElementById('poseOpacity').value) / 100;

    // util.py의 LEFT_FOOT_JOINTS, RIGHT_FOOT_JOINTS와 동일
    const LEFT_FOOT = new Set([13, 18, 19, 20]);   // LAnkle, LBigToe, LSmToe, LHeel
    const RIGHT_FOOT = new Set([10, 21, 22, 23]);  // RAnkle, RBigToe, RSmToe, RHeel

    // 선 그리기 - util.py: canvas = (canvas * pose_opacity) 후 점 그리기와 동일 효과
    ctx.globalAlpha = poseOpacity;

    for (let i = 0; i < LIMB_SEQ.length; i++) {
        const [a, b] = LIMB_SEQ[i];
        const idxA = a - 1, idxB = b - 1;
        if (idxA * 3 + 2 >= kpts.length || idxB * 3 + 2 >= kpts.length) continue;
        if (kpts[idxA * 3 + 2] <= 0.3 || kpts[idxB * 3 + 2] <= 0.3) continue;

        const x1 = kpts[idxA * 3], y1 = kpts[idxA * 3 + 1];
        const x2 = kpts[idxB * 3], y2 = kpts[idxB * 3 + 1];

        // util.py와 동일: 발 관절 포함 시 ankle 색상, 아니면 limb 인덱스 색상
        let color = BODY_COLORS[i] || BODY_COLORS[0];
        if (LEFT_FOOT.has(idxA) || LEFT_FOOT.has(idxB)) color = BODY_COLORS[13];
        else if (RIGHT_FOOT.has(idxA) || RIGHT_FOOT.has(idxB)) color = BODY_COLORS[10];

        ctx.strokeStyle = `rgb(${color[0]},${color[1]},${color[2]})`;
        // util.py: i>=17 → feet_stickwidth(가는 선), 그 외 → stickwidth
        ctx.lineWidth = i >= 17 ? Math.max(1, lineThickness - 2) : lineThickness;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    // 점 그리기 - util.py: 선에 opacity 적용 후 점은 풀 밝기로 그림
    ctx.globalAlpha = 1.0;

    const bodyPts = Math.min(24, Math.floor(kpts.length / 3));
    for (let i = 0; i < bodyPts; i++) {
        if (kpts[i * 3 + 2] <= 0.3) continue;

        // util.py와 동일: 발 관절은 ankle 색상, 아니면 키포인트 인덱스 색상
        let color = BODY_COLORS[i] || BODY_COLORS[0];
        if (LEFT_FOOT.has(i)) color = BODY_COLORS[13];
        else if (RIGHT_FOOT.has(i)) color = BODY_COLORS[10];

        ctx.fillStyle = `rgb(${color[0]},${color[1]},${color[2]})`;
        ctx.beginPath();
        // util.py: body dot_radius=4, feet_dot_radius=4 (동일)
        ctx.arc(kpts[i * 3], kpts[i * 3 + 1], pointRadius, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.globalAlpha = 1.0;
}

// drawHand - util.py draw_handpose()와 동일한 렌더링 로직
//
// [렌더러 대응]
// - 선 색상: util.py HSV(ie/20, 1.0, 1.0) = 에디터 HSL(ie/20*360, 100%, 50%) → 동일
//   HSV(h, s=1, v=1)은 수학적으로 HSL(h, s=1, l=0.5)과 완전히 동일
// - 선 두께: util.py line_thickness = max(1, 2+mod), 에디터: lineThickness-2
// - 점 색상: util.py BGR(0,0,255) = RGB(255,0,0) = 빨강 → 에디터: rgb(255,0,0) 동일
// - 점 크기: util.py dot_radius = max(1, 4+mod), 에디터: pointRadius
function drawHand(kpts, lineThickness, pointRadius) {
    if (!kpts || kpts.length < 3) return;

    for (let ie = 0; ie < HAND_EDGES.length; ie++) {
        const [a, b] = HAND_EDGES[ie];
        if (a * 3 + 2 >= kpts.length || b * 3 + 2 >= kpts.length) continue;
        if (kpts[a * 3 + 2] <= 0.1 || kpts[b * 3 + 2] <= 0.1) continue;

        const x1 = kpts[a * 3], y1 = kpts[a * 3 + 1];
        const x2 = kpts[b * 3], y2 = kpts[b * 3 + 1];

        // util.py: HSV→RGB→BGR for OpenCV, R/B swapped to match renderer output
        ctx.strokeStyle = hslToSwappedRgb((ie / HAND_EDGES.length) * 360);
        ctx.lineWidth = lineThickness;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    const handPts = Math.min(21, Math.floor(kpts.length / 3));
    for (let i = 0; i < handPts; i++) {
        if (kpts[i * 3 + 2] <= 0.1) continue;
        // util.py: BGR(0,0,255) → ComfyUI no conversion → displayed as rgb(0,0,255)
        ctx.fillStyle = 'rgb(0, 0, 255)';
        ctx.beginPath();
        ctx.arc(kpts[i * 3], kpts[i * 3 + 1], pointRadius, 0, Math.PI * 2);
        ctx.fill();
    }
}

// drawFace - util.py draw_facepose()와 동일한 렌더링 로직
//
// [렌더러 대응]
// - 점 색상: util.py (255,255,255) = 흰색 → 에디터: rgb(255,255,255) 동일
//   ※ util.py에서 (255,255,255)는 BGR이든 RGB이든 동일하게 흰색
// - 점 크기: util.py dot_radius = max(1, 3+mod), 에디터: pointRadius-1 (render()에서 전달)
// - 얼굴은 선(edge) 없이 점만 그림 (util.py와 동일)
function drawFace(pointRadius) {
    const kpts = poseData.face_keypoints_2d;
    if (!kpts || kpts.length < 3) return;

    const facePts = Math.min(68, Math.floor(kpts.length / 3));
    for (let i = 0; i < facePts; i++) {
        if (kpts[i * 3 + 2] <= 0) continue;
        // util.py: cv2.circle(..., (255, 255, 255), ...) → 흰색
        ctx.fillStyle = 'rgb(255, 255, 255)';
        ctx.beginPath();
        ctx.arc(kpts[i * 3], kpts[i * 3 + 1], pointRadius, 0, Math.PI * 2);
        ctx.fill();
    }
}

function drawSelectionHighlight(pointRadius) {
    selectedPoints.forEach(p => {
        const arr = getArrayByType(p.type);
        if (!arr || arr[p.index * 3 + 2] <= 0) return;
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(arr[p.index * 3], arr[p.index * 3 + 1], pointRadius + 4, 0, Math.PI * 2);
        ctx.stroke();
    });
}

// ========== 시작 ==========
init();
