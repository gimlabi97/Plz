"""
DWPose Editor for ComfyUI
A visual pose editor that integrates with DWPoseJSONRenderer node
"""

import os

# Web directory for JS extension
WEB_DIRECTORY = os.path.join(os.path.dirname(os.path.realpath(__file__)), "web")

# This extension doesn't add new nodes, it just adds the editor functionality
# to the existing DWPoseJSONRenderer node via JavaScript

NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS', 'WEB_DIRECTORY']

print("\033[92m[DWPose Editor] Extension loaded. Edit button will appear on DWPoseJSONRenderer nodes.\033[0m")
